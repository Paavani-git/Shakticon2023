# PDF Generator+

## Description

I developed this secure PDF generator. Can you get to my secret localhost?

## Short Writeup

Use a URL shortner service or redirection service to redirect to localhost.

## Flag

```
inctf{w311_d0N3_H4ck3rRm4N}
```

## Author

yadhu