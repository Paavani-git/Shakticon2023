const express = require('express')
const exphbs = require('express-handlebars');
const ip = require("ip");
const bodyParser = require('body-parser');
const puppeteer = require('puppeteer');
const uuid = require("uuid");
const url = require('url');
const app = express()
const dns = require("dns");
const { promisify } = require("util");
const resolve4 = promisify(dns.resolve4);
const port = 3000

app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');
app.use('/static', express.static('public'))

const urlencodedParser = bodyParser.urlencoded({ extended: false });
const ALLOWED_PROTOCOLS = ["http:", "https:"];
const BLOCKED_HOSTS = ["metadata.google.internal", "169.254.169.254", "127.0.0.1"];

app.get("/", (req, res) => {
    return res.render("main", { layout: "index" })
});

app.post("/", urlencodedParser, async (req, res) => {
    const url = decodeURIComponent(req.body.url);

    if (!url) {
      return res.render("main", { layout: "index", message: "You are blocked. Thanks for the attack." });
    }
  
    let urlObj;
    try {
      urlObj = new URL(url);
    } catch {
      return res.render("main", { layout: "index", message: "You are blocked. Thanks for the attack." });
    }
  
    const hostname = urlObj?.hostname;
  
    if (!hostname || ip.isPrivate(hostname)) {
      return res.render("main", { layout: "index", message: "You are blocked. Thanks for the attack." });
    }
  
    if (BLOCKED_HOSTS.some((blockedHost) => hostname.includes(blockedHost))) {
      return res.render("main", { layout: "index", message: "You are blocked. Thanks for the attack." });
    }
  
    const protocol = urlObj?.protocol;
    if (
      !protocol ||
      !ALLOWED_PROTOCOLS.some((allowedProtocol) =>
        protocol.includes(allowedProtocol)
      )
    ) {
      return res.render("main", { layout: "index", message: "You are blocked. Thanks for the attack." });
    }
  
    let addresses
    try {
      addresses = await resolve4(hostname);
    } catch {
      return res.render("main", { layout: "index", message: "You are blocked. Thanks for the attack." });
    }
  
    if (addresses.includes("127.0.0.1")) {
      return res.render("main", { layout: "index", message: "You are blocked. Thanks for the attack." });
    }

    
    // dont change

    try {
        const id = uuid.v4();

        (async () => {
            const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
            const page = await browser.newPage();

            await page.goto(req.body.url);
            await page.pdf({ path: `/tmp/${id}.pdf`, format: 'a4' });

            await browser.close();

            return res.sendFile(`/tmp/${id}.pdf`)
        })().catch((e) => {
            return res.render("main", { layout: "index", message: "Some error occured" })
        });

    } catch (e) {
        return res.render("main", { layout: "index", message: "Some error occured." + e })
    }
});

const http = require('http');

http.createServer(function (req, res) {
    res.write('inctf{w311_d0N3_H4ck3rRm4N}');
    res.end();
}).listen(80);

app.listen(port, () => {
});

