from flask_wtf import FlaskForm
from wtforms import StringField,SubmitField,PasswordField
from wtforms.validators import DataRequired
class Login(FlaskForm):
    username=StringField('USERNAME',validators=[DataRequired()])
    password=PasswordField('PASSWORD',validators=[DataRequired()])
    submit = SubmitField('LOGIN')