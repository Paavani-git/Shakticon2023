import os
from flask import Flask, render_template, request,url_for,redirect,send_file,session
from werkzeug.utils import secure_filename
from form import Login

app = Flask(__name__)
app.config['QUESTION_FOLDER'] = os.getenv('QUESTION_FOLDER', './questions')
app.config['ANSWER_FOLDER'] = os.getenv('ANSWER_FOLDER', './answers')
app.config['SUBMISSION_FOLDER'] = os.getenv('SUBMISSION_FOLDER', './submits')
app.secret_key = os.urandom(24).hex()

blocked_paths = ["app.py","form.py","templates","static","answers"]
blocked_users = ["Cedric_Kelly", "Haley_Kennedy", "Bradley_Greer", "Brenden_Wagner", "Bruno_Nash", "Sonya_Frost"]

dates=[f"{i}-09-2020" for i in range(29,20,-1)]

@app.route('/login', methods=['GET', 'POST'])
def login():
    form=Login()
    if request.method == 'POST':
        if form.username.data != "" and form.password.data != "":  
            username=form.username.data
            if username in blocked_users:
                return render_template('login.html', form=form, err="Sorry username already exists")
            session['user'] = username
            print(f"Logging in: {username}")
            return redirect(url_for('home'))
        else:
            err='enter a username and password to login'
            return render_template('login.html',title="login",form=form,err=err)
    return render_template('login.html',title="login",form=form)

@app.route('/logout',methods=['GET', 'POST'])
def logout():
    if session.get('user'):
        session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/')
def home():
    if session.get('user') is None:
        return redirect('/logout')
    return render_template('home.html', name=session['user'], dates=dates)

@app.route('/assignments')
def assignment():
    if session.get('user') is None:
        return redirect('/logout')
    if request.args.get('error'):
        error=request.args.get('error')
        return render_template('assignments.html',name=session['user'],error=error)
    return render_template('assignments.html', name=session['user'],dates=dates)


@app.route('/assignments/<path:id>', methods=['GET', 'POST'])
def id(id):
    if id.strip()!="flag" and not id.isdigit():
        return redirect('/assignments?error=invalid assignment id')
    if request.method == 'POST':
        try:
            f = request.files['file']
            filename=secure_filename(session['user']+"_"+id+".txt")
            print(f"{session.get('user')} Uploading File: {filename}",flush=True)
            f.save(os.path.join(app.config['SUBMISSION_FOLDER'], filename))
            return redirect(f"/assignments/{id}?stat=success")
        except Exception as e:
            print(f"{session.get('user')} : Excepting due to: ",e,flush=True)
            return redirect(f"/assignments/{id}?stat=error")
    status=None
    if request.args.get('stat'):
        status=request.args.get('stat')
    return render_template('assignment.html', id=id, status=status, name=session['user'], dates=dates)

@app.route('/leaderboard')
def leader():
    if session.get('user') is None:
        return redirect('/logout')
    return render_template('leaderboard.html', name=session['user'], dates=dates)

@app.route('/download')
def download():
    if session.get('user') is None:
        return redirect('/logout')
    id = request.args.get("question")
    err="No filename provided" if id is None else "Sorry more than 3 /  or . is not allowed" if id.count("/")>2 or id.count(".")>2 else "Sorry you don't have access to it" if any(i in id for i in blocked_paths) else None
    if err:
        print(f"{session.get('user')} Failed to download file: {id} Due to {err}", flush=True)
        return err
    file_path = os.path.join(app.config['QUESTION_FOLDER'], id+".txt")
    if(not os.path.isfile(file_path)):
        return f"No such file {file_path}"
    print(f"{session.get('user')} Downloaded file: {file_path}", flush=True)
    return send_file(file_path, as_attachment=True, download_name=id+".txt")