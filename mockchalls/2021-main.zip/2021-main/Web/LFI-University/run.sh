#!/bin/bash

cd /app
echo $FLAG > /app/answers/flag.txt
gunicorn --bind 0.0.0.0:9000 wsgi:app &
while :
do
	rm -rf /app/submits/*
    cp /app/answers/flag.txt /app/submits/Cedric_Kelly_flag.txt
	sleep 10m
done
