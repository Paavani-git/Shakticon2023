# LFI-University

### Description

Seems like you have a lot of assignments due today

### Short-Writeup

- Upload a file and know where it is stored
- find the toppers name from leaderboard and download his answer paper

### Flag

inctf{th1s_1s_h0w_pr0ff3ss10n4l5_c0py_a3767d32}

### Author

[Rohit Narayanan M](https://twitter.com/RohitNarayana11)
