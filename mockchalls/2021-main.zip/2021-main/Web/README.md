# Web

|S. No.| Challenge Name | Status  | Author |
|:---:|:--------------:|:-------:| :-: | 
|1| Polluted | Added | sk4d00sh |
|2| PDF Generator+ | Added | yadhu |
|3| World Map | Added | yadhu |
|4| figlet-II | Added | Aneesh |
|5| Blog-X | Added | Rohit |
|6| notsql | Added | Rahul |
|7| LFI-University | Added | Rohit |
|8| Simple-Calculato | Added | Sayooj |
