# faas

### Challenge Description

here is  a figlet as a service ,its only running "figlet" command ,try to hack it!



### Short Writeup

* command injection filter bypass
* `` $('ls')`` to list the files
* ``$(cat flag.txt)`` to get the flag

### Flag

inctf{l33t_win_l3v3l}

### Author

[Aneesh](https://twitter.com/mal_f0y)
