const express = require("express")
const bodyParser = require('body-parser');
const path = require('path')
const sqlite3 = require('sqlite3').verbose();

const app = express()
var db = new sqlite3.Database(path.join(__dirname,"param.db"),(err)=>{
    if(err){
        return console.error(err.message);
    }
    console.log('Connected to the "param" SQlite database.');
});
app.use(bodyParser.urlencoded({ extended: true }));
app.get("/",function(req,res){
    return res.send("Welcome to backend server")
});
app.get("/login",function(req,res){
    if(!req.query.username || !req.query.password){
        return res.json({"error":"Username or password is empty"})
    }
    user = req.query.username;
    passw = req.query.password;

    if(Array.isArray(user)){
        user = user.join("")
    }
    if(Array.isArray(passw)){
        passw = passw.join("")
    }
    query = `SELECT * FROM accounts WHERE username="${user}" AND password="${passw}"`;
    console.log(query);
    db.all(query,[],(err,rows)=>{
        if(err){
            console.log(query);
            return res.send("Database Error Occured");
        }
        if(rows.length>0){
            return res.send("inctf{p0llut3d_p4r4m3t3r5_4r3_1nt3r35t1ng}");
        }
        else{
            return res.send(user+" with password "+passw+" doesn't exist in our Database");
        }
    });

});

app.listen(5001,()=>{
    console.log("backend server running on port 5001");
});