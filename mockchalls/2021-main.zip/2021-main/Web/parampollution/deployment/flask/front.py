from flask import Flask,render_template,request
import sqlite3
import re
import requests

app = Flask(__name__)
blacklist = ["ABORT", "ACTION", "ADD", "AFTER", "ALL", "ALTER", "ALWAYS", "ANALYZE", "AND", "AS", "ASC", "ATTACH", "AUTOINCREMENT", "BEFORE", "BEGIN", "BETWEEN", "CASCADE", "CASE", "CAST", "CHECK", "COLLATE", "COLUMN", "COMMIT", "CONFLICT", "CONSTRAINT", "CREATE", "CROSS", "CURRENT", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "DATABASE", "DEFAULT", "DEFERRABLE", "DEFERRED", "DELETE", "DESC", "DETACH", "DISTINCT", "DO", "DROP", "EACH", "ELSE", "END", "ESCAPE", "EXCEPT", "EXCLUDE", "EXCLUSIVE", "EXISTS", "EXPLAIN", "FAIL", "FILTER", "FIRST", "FOLLOWING", "FOR", "FOREIGN", "FROM", "FULL", "GENERATED", "GLOB", "GROUP", "GROUPS", "HAVING", "IF", "IGNORE", "IMMEDIATE", "IN", "INDEX", "INDEXED", "INITIALLY", "INNER", "INSERT", "INSTEAD", "INTERSECT", "INTO", "IS", "ISNULL", "JOIN", "KEY", "LAST", "LEFT", "LIKE", "LIMIT", "MATCH", "MATERIALIZED", "NATURAL", "NO", "NOT", "NOTHING", "NOTNULL", "NULL", "NULLS", "OF", "OFFSET", "ON", "OR", "ORDER", "OTHERS", "OUTER", "OVER", "PARTITION", "PLAN", "PRAGMA", "PRECEDING", "PRIMARY", "QUERY", "RAISE", "RANGE", "RECURSIVE", "REFERENCES", "REGEXP", "REINDEX", "RELEASE", "RENAME", "REPLACE", "RESTRICT", "RETURNING", "RIGHT", "ROLLBACK", "ROW", "ROWS", "SAVEPOINT", "SELECT", "SET", "TABLE", "TEMP", "TEMPORARY", "THEN", "TIES", "TO", "TRANSACTION", "TRIGGER", "UNBOUNDED", "UNION", "UNIQUE", "UPDATE", "USING", "VACUUM", "VALUES", "VIEW", "VIRTUAL", "WHEN", "WHERE", "WINDOW", "WITH", "WITHOUT"]
@app.route("/",methods=["GET"])
def main():
    return render_template("index.html",message="")
@app.route("/login",methods=["GET"])
def login():
    if(request.method == "GET"):
        backend_url = f"http://localhost:5001{request.full_path}"
        user = request.args.get("username")
        passw = request.args.get("password")
        if(user and passw):
            if(len(user)>10 or len(passw)>10):
                return render_template("index.html",message="Username or password should be less than 10 characters")
            if(re.search("^[A-Za-z0-9]*$",user) and re.search("^[A-Za-z0-9]*$",passw)):
                for bword in blacklist:
                    if(bword in user.upper() or bword in passw.upper()):
                        return render_template("index.html",message="dangerous word in query detected")
                r = requests.get(backend_url)
                res_message = r.text
                return render_template("index.html",message=res_message)
            else:
                return render_template("index.html",message="Invalid character in query detected")
        else:
            return render_template("index.html",message="Username or password cannot be empty")
    else:
        return {"error":"method not allowed"}


if(__name__=="__main__"):
    app.run(host="0.0.0.0",debug=False)
