# Polluted

## Description

Can you have a look at our new website? we only have a single functionality and we are pretty sure we are safe from attacks :) 

## Short Writeup

* front end (flask) filters sqli keywords
* backend (nodejs) concats params and has sqli injection
* parameter pollution to bypass the filters in front end
* Payload ```username=adda&username=" or 1;--&password=sf```

## Flag

``inctf{p0llut3d_p4r4m3t3r5_4r3_1nt3r35t1ng}``

## Launch Challenge

```
sudo docker build -t parampollute .
sudo docker run  -p 5000:5000 parampollute
```

## Challenge Author

**[sk4d00.sh](https://twitter.com/RahulSundar8)**

