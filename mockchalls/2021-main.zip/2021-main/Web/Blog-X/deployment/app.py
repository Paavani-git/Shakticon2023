import os
from flask import Flask, render_template, request, url_for, redirect, send_file, session

app = Flask(__name__)
app.secret_key = os.urandom(24).hex()


@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('home.html')

@app.route('/proxy')
def vpn():
    return render_template('proxy.html')

@app.route('/blog<path:id>')
def blog(id):
    if not id.isdigit():
        return redirect(url_for('home'))
    elif not request.headers.get('X-Forwarded-For'):
        return "Your ip is does not look local"
    if '127.0.0.1' in request.headers.get('X-Forwarded-For').split(','):
        return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")

@app.route('/flag')
def admin():
    if not request.headers.get('X-Forwarded-For'):
        return "Your ip is does not look local"
    if '127.0.0.1' in request.headers.get('X-Forwarded-For').split(','):
        return os.getenv("FLAG", "inctf{test_flag}")

if __name__=="__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
