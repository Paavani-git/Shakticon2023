# Blog-X

### Description

Oh, just the proxy is broken. I think you can replicate it

### Short-Writeup

- Send a request to "/flag" with header `X-Forwarded-For: 127.0.0.1`

### Flag

inctf{7hat's_50m3_n1ce_5p00f1ng_with_X_F0rw4rd3d_F0r_fd27a12a}

### Author

[Rohit Narayanan M](https://twitter.com/RohitNarayana11)
