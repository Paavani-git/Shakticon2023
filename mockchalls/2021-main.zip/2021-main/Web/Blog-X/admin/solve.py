import requests
import re
import os

#python example of gettting host host
host=os.getenv('CI_REGISTRY_IMAGE','localhost:5000').replace('/','-')
url = "http://"+host
r=requests.get(url+"/flag",headers={"X-Forwarded-For":"127.0.0.1"})
print(r.text)