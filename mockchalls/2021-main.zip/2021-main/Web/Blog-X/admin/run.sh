#!/bin/sh
cd admin

curl $(echo $CI_REGISTRY_IMAGE | sed "s/\//-/g")

python3 solve.py