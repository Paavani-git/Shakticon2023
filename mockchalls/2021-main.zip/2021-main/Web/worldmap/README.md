# World Map

## Description

I have hidden a treasure in this world map. Can you find it?

## Short Writeup

Read sitemap.xml to identify hidden endpoint and get flag. 

## Flag

```
inctf{th3_s3cReT_Mag1c4l_N0t3}
```

## Author

yadhu