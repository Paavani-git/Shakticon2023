import requests
import os

#python example of gettting host host
host=os.environ['CI_REGISTRY_IMAGE'].replace('/','-')
url = "http://"+host