<?php
$expression=$_POST["expression"];
$output = eval("return ".$expression.';');
echo $output;
?>
