// This function clear all the values
function clearScreen() {
    document.getElementById("result").value = "";
}


// This function display values
function display(value) {
    document.getElementById("result").value += value;
}

// This function evaluates the expression and return result
function calculate() {
    var formBody = [];
    var p = document.getElementById("result").value;
    p=encodeURIComponent(p);
    const data="expression="+p;
    formBody.push(data);
    fetch('calc.php', {
    method: 'POST',
    headers: {
    	"Content-type": "application/x-www-form-urlencoded",
    },
    body: formBody,
    })
    .then(response => response.text())
    .then(data => {
  	    document.getElementById("result").value =data;
    })
}

