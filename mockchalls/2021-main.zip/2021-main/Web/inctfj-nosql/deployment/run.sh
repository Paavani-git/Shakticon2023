mongod &
sleep 3
mongorestore dbdump/ &
sleep 3
node app.js