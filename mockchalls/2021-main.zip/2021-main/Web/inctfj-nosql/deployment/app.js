const express = require("express")
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const mongo = require("mongodb").MongoClient;
const app = express()
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.set('view engine', 'ejs');
app.use(express.static('public'));

let url = 'mongodb://localhost:27017/';
var db;
var resultDocs= [];
mongo.connect(url,function(err,client){
    if(err) throw err;
    client = client;
    db = client.db("noteacc");
});


// ROUTES
app.get("/",function(req,res){
    res.redirect("/login");
});

app.get("/login",function(req,res){
    res.render("login.ejs",{message:""});
});

app.get("/notes",function(req,res){
    if(req.cookies.session){
    res.render("notes.ejs",{user:req.cookies.session,flag:req.cookies.flag});
    }else{
        res.redirect("/login");
    }
});

app.post("/login",function(req,res){
    console.log(req.body.username);
    console.log(req.body.pass);
    var resultDocs= [];
    var doc = {
        "username": req.body.username,
        "password": req.body.pass
    };
    let query = {"username":req.body.username,"password":req.body.pass};
    console.log(query);
    var cursor = db.collection("users").find(query);
    cursor.forEach(function(doc,err){
        if(err) throw err;
        resultDocs.push(doc);
    },function(){
        if(resultDocs.length != 0){
            console.log("Logged in");
            if(resultDocs[0].username=="admin"){
                res.cookie("flag","inctf{n0SQL_15_n0t_s3cur3_6784}");
            }
            res.cookie("session",req.body.username);
            res.redirect("/notes");
        }else{
            res.render("login.ejs",{message:"Password or username is incorrect"});
        }
    });
});

app.get("/register",function(req,res){
    res.render("register.ejs",{message:""});
});

app.post("/register",function(req,res){
    console.log(req.body.username);
    console.log(req.body.pass);
    var resultDocs= [];
    var doc = {
        "username": req.body.username.toString(),
        "password": req.body.pass.toString()
    };
    var cursor = db.collection("users").find({"username":req.body.username.toString()});
    cursor.forEach(function(doc,err){
        if(err) throw err;
        resultDocs.push(doc);
    },function(){
        if(resultDocs.length == 0){
            console.log("user doesn't exist");
            db.collection("users").insertOne(doc,function(err,result){
                if(err) throw err;
                console.log("Item inserted");
            });
            res.render("register.ejs",{message:"Successfully Registered!"});
        }else{
            res.render("register.ejs",{message:"Username already exists!"});
        }
    });
});

app.listen(5000,()=>{
    console.log("server running on port 5000");
});
