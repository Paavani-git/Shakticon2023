# Journey to the Center of the Earth

### Challenge Description

Can you dig down to the center of the Earth?

**Challenge File**:

+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Forensics/Journey%20to%20the%20Center%20of%20the%20Earth/Handout/journey_begins.zip)

### Short Writeup

- Unzip 50 nested zip file using any programming language.

### Flag

inctf{YoU_M4d3_1t}

### Author:

[P4BLØ](https://twitter.com/GouthamRajesh5)







