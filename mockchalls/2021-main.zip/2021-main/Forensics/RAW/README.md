# RAW

### Challenge Description

- Gary loves music. He tries to imagine while listening to music(2930x2930) :)

**Challenge File**

+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Forensics/RAW/Handout/Oliver_Tree.mp3)

### Short Writeup

- Change the audio format to raw
- Open it in gimp,photoshop or any other image editor that can open raw file with the given resolution


### Flag

Flag - inctf{g4ry_know5_5t3g0}

### Author

[P4BLØ](https://twitter.com/GouthamRajesh5)
