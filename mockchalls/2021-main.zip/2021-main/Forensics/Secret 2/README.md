#  Secret 2

### Challenge Description

What is the information that might help us reach the criminal?

**Challenge File**

Same as Secret 1

### Short Writeup

Extract information.txt from Documents and open the mega link. Reverse the zip file and use the string which cmdscan gives as the password for the zip file.

### Flag

inctf{W3Ll_y0U_g0T_wH4T_yOu_N33d3D}

### Author

[v1Ru5](https://twitter.com/SrideviKrishn16) & [d3liri0us](https://twitter.com/d3liri0us_)
