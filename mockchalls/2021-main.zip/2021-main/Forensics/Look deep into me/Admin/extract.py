import codecs
a=[];
with open('deep.pdf', 'rb') as p:
	pp =p.read().hex()
	ppp=codecs.decode(pp,"hex")
	k=ppp[68315:]
	k=k[::-1]
with open('z.png', 'wb') as m:
	m.write(k)

