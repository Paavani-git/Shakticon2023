import codecs
a=[];
with open('em.pdf', 'rb') as p:
	with open('k.png','rb') as d:
		dd =d.read().hex()
		pp =p.read().hex()
		ppp=codecs.decode(pp,"hex")
		ddd=codecs.decode(dd,"hex")
		z=ppp[:68315]+ddd[::-1]+ppp[68315:]+b'aWxvdmV5b3UzMDAw=='
		print(z)
with open('deep.pdf', 'wb') as m:
	m.write(z)


#k="35 0 obj<<>> stream endstream endobj
