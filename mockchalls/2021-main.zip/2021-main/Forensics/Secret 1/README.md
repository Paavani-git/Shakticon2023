#  Secret 1

### Challenge Description

Our team is on a secret mission and we could only recover the memory dump of the prime suspect's laptop. Your job is to find out some useful information that might help us reach the criminal. Analyze the memory dump and answer the following questions.

1. Which is the most appropriate volatility profile for this machine?
2. What is the LM hash of TroubleMaker's account?
3. What is its md5 hash of cmd.exe process?

Flag Format : inctf{profile_LMhash_md5hash}
 
**Challenge File**

+ [Primary Link](https://mega.nz/file/gjIlQAzQ#Od9vio3ZZbbLNpYneW0tGvXaPmjtVYt48n93s0FB9QA)

### Short Writeup

+ imageinfo
+ hashdump
+ procdump

### Flag

inctf{Win7SP1x64_aad3b435b51404eeaad3b435b51404ee_c23f73ab92ecaa4adbbdb603dd92cb63}

### Author

[v1Ru5](https://twitter.com/SrideviKrishn16) & [d3liri0us](https://twitter.com/d3liri0us_)
