from __future__ import print_function
from scapy.all import *
import hashlib
r=rdpcap("nww.pcap")
happy=open("nww","wb")
d='';l=[];data=''
for i in range(256):
    h=hashlib.md5(str(i).encode()).hexdigest()
    l.append(str(h))
for i in range(len(r)):
    b=len(r[i][TCP].payload)
    c=str(r[i][TCP].payload)
    z=c[c.rfind("=")+1:]
    if(b==15 or b==14 or b==16):
        happy.write(chr(int(z)))
        d=d+c[-1]
    if(b==109):
        d=d+str(l.index(z))
        happy.write(chr(l.index(z)))
print(d)
