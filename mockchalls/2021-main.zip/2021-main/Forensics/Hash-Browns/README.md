# Hash Browns

## Challenge Description 

My friend and me has been playing a game. I am trying to reconstruct an image sent by him. Can you help me? 

## Challenge file

[Primary link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Forensics/Hash-Browns/Handout/hash-browns.pcap)

## Short write up

We send one byte at a time and compare it with the original image.If they are same then server sends "Matched byte" signal. If the bytes don't match server sends error message including MD5 hash of the received byte and MD5 hash of the original byte.

Write a scapy script to reconstruct the PNG. If the byte is matched, add it directly, or if its an errored byte, find the original byte using md5 hash of it.

## Flag 

inctf{g00d_joB_m4te!!}

## Author 
[Chetak](https://twitter.com/Sampath53509318)&
[rayst4rk](https://twitter.com/rayst4rk)
