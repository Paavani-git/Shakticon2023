# Forensics

|S.No| Challenge Name | Status  | Author |
|:---:|:--------------:|:-------:| :-: | 
| 1 | [Hash Browns](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Forensics/Hash-Browns)| Done | [Sampath](https://twitter.com/Sampath53509318) & [Arya Arun](https://twitter.com/rayst4rk) |
| 2 | [RAW](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Forensics/RAW)| Done | [P4BLØ](https://twitter.com/GouthamRajesh5) |
| 3 | [Look deep into me](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Forensics/Look%20deep%20into%20me) | Done | [Arya Arun](https://twitter.com/rayst4rk) | 
| 4 | [Journey to the Center of the Earth](https://gitlab.com/teambi0s/inctf-junior/quals/2021/-/tree/main/Forensics/Journey%20to%20the%20Center%20of%20the%20Earth) | Done | [P4BLØ](https://twitter.com/GouthamRajesh5) |
| 5 | [Follow me](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Forensics/Follow%20me) | Done | [Sampath](https://www.linkedin.com/in/sai-sampath-863a7b1aa/)|
| 6 | [Secret 1](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Forensics/Secret%201) | Done | [v1Ru5](https://twitter.com/SrideviKrishn16) & [d3liri0us](https://twitter.com/d3liri0us_)|
| 7 | [Secret 2](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Forensics/Secret%202) | Done | [v1Ru5](https://twitter.com/SrideviKrishn16) & [d3liri0us](https://twitter.com/d3liri0us_)|

