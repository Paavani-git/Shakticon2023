# Follow me

### Challenge Description

- DOn''t follow me you might get lost.(or maybe not ;))


### Short Writeup

- Follow the tcp and change the extenstion to .docx

### Flag

Flag - inctf{U_f0und_th3_flag_;)}

### Author

Sampath

