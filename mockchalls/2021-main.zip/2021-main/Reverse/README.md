# Reverse

|S. No.| Challenge Name | Status  | Author |
|:---:|:--------------:|:-------:| :-: | 
| 1 | [Nagini](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/Nagini) | Done | [Ad0lphus](https://twitter.com/Ad0lphu5) | 
| 2 | [Chequered_flag](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/Chequered_flag) | Done | Abhishek Barla
| 3 | [sundae](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/sundae) | Done | Namitha
| 4 | [Condensed](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/Condensed) | Done | [AmunRha](https://twitter.com/amun_rha)
| 5 | [USLS Encrypter](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/USLS_Encrypter) | Done | [AmunRha](https://twitter.com/amun_rha)
| 6 | [KeyLock](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/KeyLock) | Done | imm0rt4l_5t4rk
| 7 | [dungeon](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/dungeon) | Done | fug1t1ve
| 8 | [Big Numbers](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Reverse/Big_numbers) | Done | Revathi
