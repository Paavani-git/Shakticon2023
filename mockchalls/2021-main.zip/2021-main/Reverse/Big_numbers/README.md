# Big numbers

### Challenge description

Simple understanding in c++ will help you in getting flag.

**Challenge File**:
+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Reverse/Big_numbers/Handout/Big)

### Short writeup

- This is cpp reversing challenge. There are set of values which are xored with ``0xab``. The output of these values are again xored with return values of ``f`` function. 

- Finally ascii values of our input string are compared with output values returned after xoring with ``f`` function. Writing the python code for the above process, we get the flag.

### Flag
inctf{g00d_g01ng_y0u_g0t_the_f1ag}

### Author
**Revathi**
