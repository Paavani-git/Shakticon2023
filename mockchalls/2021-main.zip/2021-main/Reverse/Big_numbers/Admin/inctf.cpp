#include <iostream>
#include <string>
#include<bits/stdc++.h>
using namespace std;

int f(int n);
int conv(string s);

int f(int n)
{
	if(n==0)
		return 0;
	if(n==1 || n==2)
		return 1;
	int x=f(n>>1);
	int y=f(n/2+1);
	if(!(n&1))
		return (x*((2*y)-x));
	else
		return x*x+y*y;
}

		
int conv(string s)
{
    int res = 0;
    for(int i=0;i<(int )s.length();i++){
        res*=16;
        int temp;
        if(s[i]<='9'){
            temp = int(s[i]-'0');
        } else {
            temp = 10+int(s[i]-'a');
        }
        res+=temp;
    }
    return res;
}

int main()
{
	vector<int> l={ 194,196,201,221,206,
			213,196,150,142,237,
			195,149,11,115,444,
			686,815,1775,2691,4235,
			6809,10766,17844,28462,46548,
			75214,121586,196492,317831,514168,
			832178,1346071,2178505,3524404};
	string str;
	cout << "Enter flag to be checked\n";
	getline(cin,str);
	int n=str.length();
	if(n!=34)
	{
		cout << "You have entered flag of wrong length\n";
		return 0;
	}
	int b[n],flag_dec[n],c=0;
	char hex[]="ab";
	for(int i=0;i<n;i++)
	{
		b[i]=l[i]^conv(hex);
	}
	for(int i=0;i<n;i++)
	{
		flag_dec[i]=b[i]^f(i);
		if(str[i]!=char(flag_dec[i]))
		{
			c=1;
			break;
		}
	}
	if(c==0)
		cout << "You have entered correct flag\n";
	else
		cout << "Good try but your flag is incorrect\n";
	return 0;
}



