#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#define PORT 8080
   
int main(int argc, char const *argv[])
{
    int sock = 0, valread;
    struct sockaddr_in serv_addr;
    char *hello = "yo";
    char buffer[1024] = {0};
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Socket creation error \n");
        return -1;
    }
   
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
       
    if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0) 
    {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }
   
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
        printf("\nConnection Failed \n");
        return -1;
    }
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    send(sock , "3" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    send(sock , "5" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    char *msg="The secret we should never let the gamemasters know is that they don't need any rules .";
    send(sock,msg,strlen(msg),0);
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    
    send(sock , "2" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock,"4 1",3,0);
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock , "2" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock,"4 0",3,0);
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock , "2" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock,"4 2",3,0);
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock , "2" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock,"4 3",3,0);
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock , "2" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock,"4 4",3,0);
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    send(sock , "1" , 1 , 0 );
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    send(sock,"y",1,0);
    send(sock,"h",1,0);
    send(sock,"h",1,0);
    send(sock,"h",1,0);
    send(sock,"h",1,0);
    send(sock,"h",1,0);
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    memset(&buffer[0], 0, sizeof(buffer));
    valread = read( sock , buffer, 1024);
    printf("%s\n",buffer );
    close(sock);
    return 0;
}