#include <pthread.h>
#include <semaphore.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#define PORT 8080

sem_t x, y;
pthread_t tid;
pthread_t writerthreads[100];
pthread_t readerthreads[100];
int readercount = 0;

int allowed=10;
char inventory[5][100]={"weak sword","weak armour","weak magic","weak health","weak strength"};
int cash;
char buffer[1024] = {0};
static char encoding_table[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
                                'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
                                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',
                                'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
                                'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
                                'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
                                'w', 'x', 'y', 'z', '0', '1', '2', '3',
                                '4', '5', '6', '7', '8', '9', '+', '/'};
static char *decoding_table = NULL;
static int mod_table[] = {0, 2, 1};

void build_decoding_table() {

    decoding_table = malloc(256);

    for (int i = 0; i < 64; i++)
        decoding_table[(unsigned char) encoding_table[i]] = i;
}


void base64_cleanup() {
    free(decoding_table);
}

char* flag_read(){
    char *s = (char*)malloc(255);
    FILE *fptr;
    fptr=fopen("./flag.txt","r");
    fscanf(fptr,"%s", s);
    fclose(fptr);
    return s;
}

char *base64_encode(const unsigned char *data,
                    size_t input_length,
                    size_t output_length) {

    output_length = 4 * ((input_length + 2) / 3);

    char *encoded_data = malloc(output_length);
    if (encoded_data == NULL) return NULL;

    for (int i = 0, j = 0; i < input_length;) {

        uint32_t octet_a = i < input_length ? (unsigned char)data[i++] : 0;
        uint32_t octet_b = i < input_length ? (unsigned char)data[i++] : 0;
        uint32_t octet_c = i < input_length ? (unsigned char)data[i++] : 0;

        uint32_t triple = (octet_a << 0x10) + (octet_b << 0x08) + octet_c;

        encoded_data[j++] = encoding_table[(triple >> 3 * 6) & 0x3F];
        encoded_data[j++] = encoding_table[(triple >> 2 * 6) & 0x3F];
        encoded_data[j++] = encoding_table[(triple >> 1 * 6) & 0x3F];
        encoded_data[j++] = encoding_table[(triple >> 0 * 6) & 0x3F];
    }

    for (int i = 0; i < mod_table[input_length % 3]; i++)
        encoded_data[output_length - 1 - i] = '=';
    return encoded_data;
}

char* substr(const char *src, int m, int n)
{
    int len = n - m;
    char *dest = (char*)malloc(sizeof(char) * (len + 1));
    for (int i = m; i < n && (*(src + i) != '\0'); i++)
    {
        *dest = *(src + i);
        dest++;
    }
    *dest = '\0';
    return dest - len;
}

int fight(int new_socket)
{
    int Dragonhealth=20001;
    memset(&buffer[0], 0, sizeof(buffer));
    char *intro="\n\n Dragon:YOU,you mere mortal dare challenge me you are nothing but a human and i am the king of dragons\n\n";
    char *chance="\n\n Cameraman:you sure?you really wanna do this with the stuff you got?\n\n";
    char *coward="\n\n Dragon: did i see someone at the entrance ? Ig some cowards who thought they could beat me and pissed their pants and ran away after entering the cave.\n\n";
    send(new_socket , chance , strlen(chance) , 0 );
    for(int i=0;i<5;i++)
    {
        send(new_socket , strcat(inventory[i],"\n") , strlen(inventory[i])+1 , 0 );
    }
    int valread = read( new_socket , buffer, 1024);
    char yesorno=buffer[0];
    memset(&buffer[0], 0, sizeof(buffer));
    if(yesorno!='y')
    {
        send(new_socket , coward , strlen(coward) , 0 );
        return 0;
    }
    int stats[5]={0,0,0,0,0};
    for(int i=0;i<5;i++)
    {
        if(strncmp(inventory[i],"weak",4)==0)
        {
            stats[i]=1;
        }
        else if(strncmp(inventory[i],"decent",6)==0)
        {
            stats[i]=5;
        }
        else if(strncmp(inventory[i],"strong",6)==0)
        {
            stats[i]=10;
        }
        else if(strncmp(inventory[i],"legendary",9)==0)
        {
            stats[i]=100;
        }
        else if(strncmp(inventory[i],"special",7)==0)
        {
            stats[i]=200;
        }
    }
    int tries=0;
    while(Dragonhealth!=0&&tries!=5)
    {
        memset(&buffer[0], 0, sizeof(buffer));
        valread=read( new_socket , buffer, 1024);
        char action=buffer[0];
        int dmg=0;
        int health=0;
        int magic=0;
        int strength=0;
        switch (action)
        {
        case 'h':Dragonhealth-=(stats[0]+stats[4])*stats[2];stats[3]-=50;tries-=1;break;
        case 'd':stats[3]-=50-stats[1];break;
        default:exit(0);break;
        }
        if (Dragonhealth>0&&stats[3]<1)
        {
            send(new_socket,"\n\nyou died",10,0);
            return 0;
        }
        if (Dragonhealth<1)
        {
            send(new_socket,"\n\nyou won",9,0);
            return 0x109;
        }
        if(tries>5)
        {
            stats[3]=0;
        }
    }
    return 0;
}

int shop(int new_socket)
{
    char *inv="\t\tWELCOME TO THE SHOP\n\n";
    send(new_socket , inv , strlen(inv) , 0 );
    char *what="\n\n\t\twhat would you like to buy\n\n\t\tTo buy a particular euipment from a set,select the set number and the quipment number in that set\n\n for ex: Strong weapon input should be 3 1";
    send(new_socket , what , 1024 , 0 );
    char *op="\n\t\tSo what do you want to buy?:";
    send(new_socket , op , 1024 , 0 );
    
    int valread=read( new_socket , buffer, 1024);
    char *token = strtok(buffer, " ");
    int set=atoi(token);
    int item=atoi(strtok(NULL," "));
    char shop[25][100]={"weak sword","weak armour","weak magic","weak health","weak strength","decent sword","decent armour","decent magic","decent health","decent strength","strong sword","strong armour","strong magic","strong health","strong strength","legendary sword","legendary armour","legendary magic","legendary health","legendary strength","special sword","special armour","special magic","special health","special strength"};
    int price[25]={50,50,50,50,50,100,100,100,100,100,200,200,200,200,200,400,400,400,400,400,1000,1000,1000,1000,1000};
    int cost=price[5*(set)+item];
    if(cash<cost)
    {
        char *poor="\n\t\t Sorry but you are poor\n\n";
        send(new_socket , poor , 1024 , 0 );
    }
    else{
        strcpy(inventory[item],shop[5*(set)+item]);
        cash=cash-cost;
    }
    char *end="\n\t\t Leaving the shop,visit again :) \n\n";
    send(new_socket , end , strlen(end) , 0 );
    return 0;
}

int job1(int new_socket)
{
        char *job1="\n\t\tSo you selected the easy job,you will get paid only 1 cash for this remember\n\n\t\there is your number send the random numbers used to get this (format:a b)\n";
        int a=rand();
        int b=rand();
        int c=a+b;
        char sc[10];
        sprintf(sc, "%d", c);
        send(new_socket , job1 , strlen(job1) , 0 );
        send(new_socket , sc , strlen(sc) , 0 );
        memset(&buffer[0], 0, sizeof(buffer));
        int valread = read( new_socket , buffer, 1024);
        char *token = strtok(buffer, " ");
        int preda=atoi(token);
        int predb=atoi(strtok(NULL," "));
        if(preda==a&&predb==b)
        {
            cash++;
        }
        else if(preda==b&&predb==a)
        {
            cash++;
        }
}

int farm(int new_socket)
{
    char *employee="\n\n\t\tHey, you over there you here for cash?Then lets give you the list of jobs\n\t\t1.find the random variable - 1 cash\n\n\t\t2.find the co-prime - 5 cash\n\n\t\t3.stand with ceaser - 10 cash\n\n\t\t4.Tough one - 50";
    allowed--;
    send(new_socket , employee , strlen(employee) , 0 );
    if(allowed==-1)
    {
        char *WTF="There is a limit to number of jobs you can do ,you have passed that";
        send(new_socket , WTF , strlen(WTF) , 0 );
        return 0;
    }
    memset(&buffer[0], 0, sizeof(buffer));
    int valread = read( new_socket , buffer, 1024);
    int option=buffer[0];
    switch (option)
    {
    case 0x31:
        job1(new_socket);
        break;
    case 0x32:
    {
        int a=rand();
        int hcf,b;
        char *job2="\n\t\tSo you selected the 2nd job,you will get paid only 5 cash for this remember\n\n\t\there is your number send the co prime of this number\n";
        send(new_socket , job2 , strlen(job2) , 0 );
        char sa[10];
        sprintf(sa,"%d",a);
        send(new_socket , sa , strlen(sa) , 0 );
        memset(&buffer[0], 0, sizeof(buffer));
        int valread = read( new_socket , buffer, 1024);    
        b=atoi(buffer);
        for(int i=1;i<=a;i++)
	    {
	        if(a%i==0 && b%i==0)
	        {
	            hcf = i;
	        }
	    }
        if(hcf==1)
        {
            cash=cash+5;
        }
        break;
    }
    case 0x33:
    {
        int a=rand();
        int hcf,b;
        char *job3="\n\t\tSo you selected the 3rd job,you will get paid only 10 cash for this remember\n\n\t\there take this message to ceaser,can you tell me what are you going to say to him?\n";
        send(new_socket , job3 , strlen(job3) , 0 );
        memset(&buffer[0], 0, sizeof(buffer));
        int valread = read( new_socket , buffer, 1024);
        for(int i=0;i<152;i++)
        {
            buffer[i]=buffer[i]+7;
        }
        if(strncmp("dear ceaser this is a message from the tax department please pay this guy 10 cash as this months tax.If you dont pay we will visit with police next time",buffer,152)==0)
        {
            cash=cash+10;
        }
        break;
    }
    case 0x34:
    {    
        int p=11;
        char sp[10],sq[10],se[10];
        int q=13;
        int e=107;
        sprintf(sp, "%d", p);
        sprintf(sq, "%d", q);
        sprintf(se, "%d", e);
        char *job4=strcat(strcat(strcat(strcat(strcat(strcat("\n\t\tSo you selected the hard job,you will get paid only 50 cash for this remember\n\n\t\there take this message use your private key to decrypt this(p=",sp),",q="),sq),",e="),se),")\n\t\tWhat is the msg you got?\n");
        send(new_socket , job4 , strlen(job4) , 0 );
        memset(&buffer[0], 0, sizeof(buffer));
        int valread = read( new_socket , buffer, 1024);
        int d=atoi(buffer);
        int D=((int)pow(75,d))%(p*q);
        if(D==69)
        {
            cash=cash+50;
        }
        break;
    }
    case 0x35:
    {
        char *secret="VGhlIHNlY3JldCB3ZSBzaG91bGQgbmV2ZXIgbGV0IHRoZSBnYW1lbWFzdGVycyBrbm93IGlzIHRoYXQgdGhleSBkb24ndCBuZWVkIGFueSBydWxlcyAu";
        send(new_socket,secret,strlen(secret),0);
        memset(&buffer[0], 0, sizeof(buffer));
        int valread = read( new_socket , buffer, 1024);
        char *enc=base64_encode(buffer,strlen(buffer),0);
        if(strncmp(secret,enc,strlen(secret))==0)
        {
            cash=cash+100000;
            return 1;
        }
        break;
    }
    default:
    {    
        send(new_socket,"Stop it.get some help",21,0);
        break;
    }
    }
    return 0;
}

int dungeon(int new_socket)
{
    char *enc="\t\t\tWelcome to the Hardest Dungeon of the planet\n\t\t\t1>Fight\n\t\t\t2>Shop\n\t\t\t3>Farm\n\t\t\t4>help\n";    
    int result=0;
    while(result!=0x109)
    {
        send(new_socket , enc , strlen(enc) , 0 );
        memset(&buffer[0], 0, sizeof(buffer));
        int valread = read( new_socket , buffer, 1024);
        int option=buffer[0];
        switch(option)
        {
            case 0x31:result=fight(new_socket);break;
            case 0x32:shop(new_socket);break;
            case 0x33:farm(new_socket);break;
            case 0x34:send(new_socket , "\n\n\t\tsend 1 to fight the dragon\n\t\tsend 2 to shop\n\t\tsend 3 to farm and get cash\n\t\tsend 4 to get this help page\n\t\telse get out" , 123, 0 );break;
            default:return 0;
        }
    }
    return result;
}

int main(int argc, char const *argv[])
{
    int server_fd, new_socket, valread;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons( PORT );
    if (bind(server_fd, (struct sockaddr *)&address, 
                                 sizeof(address))<0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 3) < 0)
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }
    while(1)
    {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, 
                           (socklen_t*)&addrlen))<0)
        {
            perror("accept");
            exit(EXIT_FAILURE);
        }
        int pid;
        pid=fork();
        if(pid<0){
            perror("Spoon");
            close(new_socket);
            exit(0);
        }
        if(pid==0)
        {
            close(server_fd);
            int clear=dungeon(new_socket);
            memset(&buffer[0], 0, sizeof(buffer));
            if(clear){
                char *flag=flag_read();
                send(new_socket , flag , 1024 , 0 );
            }
            close(new_socket);
            exit(0);
        }
        else {
            wait(NULL);
            close(new_socket);
        }
    }
    return 0;
}

