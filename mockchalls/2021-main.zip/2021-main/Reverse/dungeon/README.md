# Dungeon

### **Challenge Description**

Welcome to the dungeon of inctf here you have to find the hidden treasure beware i have heard there is a guard for that treasure, i am giving you the data i found you have to get a client.c to defeat that guard and get the flag all the best

[**challenge file**](https://drive.google.com/file/d/1P8OuA829X89ujmQ_CAVsO-5c2SzJRjZ5/view?usp=sharing)

### **Short writeup**

we have provided the server binary and the participant has to make a client inorder to get the flag,there are some basic encryptions and stuff init.

### **Flag**

inctf{So_c0mes_snow_aft3r_f1re_and_3ven_dr4gons_have_their_ending5}

### **Author**
[**fug1t1ve**](https://twitter.com/fug1t1v31)