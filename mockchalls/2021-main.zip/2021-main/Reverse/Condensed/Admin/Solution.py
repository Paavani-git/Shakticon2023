a = "159^255^255^119^99^167^27^253^23^11^31^171^87^51^103^117^79^203^201^103^41^55^119^199^199^197"
a = a.split('^')
a = [int(i, 0) for i in a]
b = []

for i in a:
    t1 = format(i, '#010b')[2:][::-1]
    b.append(t1)

c = "once_a_pepe_always_a_pepe!"
d = []
for i in c:
    t1 = format(ord(i), '#010b')[2:]
    d.append(t1)

e = []
for i, j in zip(b, d):
    f = ""
    for m, n in zip(i, j):
        if m == n:
            f+="1"
        else:
            f+="0"
    e.append(f)

g = []
for i in e:
    t1 = int(i, 2)
    g.append(chr(t1))

print(''.join(g))
