# flag = pepega = inctf{x0r_but_n0t_3x4ctly}
# output = ^159^255^255^119^99^167^27^253^23^11^31^171^87^51^103^117^79^203^201^103^41^55^119^199^199^197^
pepega = ""
pepebrrr = "once_a_pepe_always_a_pepe!"
print("^", end='')
pepe_cool = lambda hello, hey: [print(j, end='^') for i in [([str(int("0b" + i[::-1], 0)) for i in [''.join([("1" if (1 if x == y else 0) else "0") for x,y in zip(i,j)]) for i,j in zip([(format(ord(i), '#010b')[2:]) for i in hello],[(format(ord(i), '#010b')[2:]) for i in hey])]]) if type(hello) == str or type(hey) == str else (hello, hey)] for j in i]
pepe_cool(pepega, pepebrrr)