# Condensed

### Challenge Description

I know, I know, everyone likes python, but my goal this time is to get you to hate python, it's annoying, it's frustrating, and it's pointless. But everything said, it's still python. Let's see how you go against my sweet little one liner.

Here is the encrypted version,
`^159^255^255^119^99^167^27^253^23^11^31^171^87^51^103^117^79^203^201^103^41^55^119^199^199^197^`

*p.s. ^ operator in the encrypted output string is not meant to denote xor operation, it's just a divider/placeholder between each given number*

**Note:** `pepega` is the variable for "flag" and `pepebrrr` is the variable for the key


**Challenge File**:
+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Reverse/Condensed/Handout/Condensed.py)

### Short Writeup

For every character in the flag and the key, this is what happens

```python
a =  !xor(flag[i], key[i % len(key)])
b = bin(a)[::-1]
c = int(b)
```

Here is the solve script, 

```python
a = "159^255^255^119^99^167^27^253^23^11^31^171^87^51^103^117^79^203^201^103^41^55^119^199^199^197"
a = a.split('^')
a = [int(i, 0) for i in a]
b = []

for i in a:
    t1 = format(i, '#010b')[2:][::-1]
    b.append(t1)

c = "once_a_pepe_always_a_pepe!"
d = []
for i in c:
    t1 = format(ord(i), '#010b')[2:]
    d.append(t1)

e = []
for i, j in zip(b, d):
    f = ""
    for m, n in zip(i, j):
        if m == n:
            f+="1"
        else:
            f+="0"
    e.append(f)

g = []
for i in e:
    t1 = int(i, 2)
    g.append(chr(t1))

print(''.join(g))

```

### Flag

inctf{x0r_but_n0t_3x4ctly}

### Author

**AmunRha**



