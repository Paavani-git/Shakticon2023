syrup=4
sauce=[66666,55555,44444,33333]
cream=[]
gg=[]
mix=[]
def cmp(a, b):
    return (a > b) - (a < b)
def Whipped_cream(Butter,key):
    for i in key:
        Butter[3]=((Butter[3]^i)-117) 
    for i in key:
        Butter[6]=((Butter[6]^i)+43)
    for i in key:
        Butter[9]=((Butter[9]^i)-99) 
    for i in key:
        Butter[12]=((Butter[12]^i)-10)  
    for i in key:
        Butter[15]=((Butter[15]^i)+115)  
    for i in key:
        Butter[18]=((Butter[18]^i)+75)  
    for i in key:
        Butter[21]=((Butter[21]^i)-22)  
    for i in key:
        Butter[24]=((Butter[24]^i)-118)  
    for i in key:
        Butter[27]=((Butter[27]^i)+38)  
    for i in key:
        Butter[30]=((Butter[30]^i)+66)  
    for i in key:
        Butter[2]=((Butter[2]^i)-117)  
    for i in key:
        Butter[4]=((Butter[4]^i)+43)  
    for i in key:
        Butter[8]=((Butter[8]^i)-99)  
    for i in key:
        Butter[10]=((Butter[10]^i)-10)  
    for i in key:
        Butter[14]=((Butter[14]^i)+115)  
    for i in key:
        Butter[16]=((Butter[16]^i)+75)  
    for i in key:
        Butter[20]=((Butter[20]^i)-22)  
    for i in key:
        Butter[22]=((Butter[22]^i)-118)  
    for i in key:
        Butter[26]=((Butter[26]^i)+38)  
    for i in key:
        Butter[28]=((Butter[28]^i)+66)  
    return Butter
def Vanilla_Essence():
  
    for i in range (len(sauce)):
        mix.append(int((bin(sauce[i])[3:]),2)^7)
    return mix
def CoCoAAA(inp):
    
    for i in range(0,len(inp)):
        cream.append(((ord(inp[i])&0xf)>>4)|(ord(inp[i])<<4))
        gg.append(cream[i]^45)
    return gg
def  Chocolate_ice_cream(choco,s): 
    result = [] 
    for i in range(len(choco)): 
        char = choco[i] 
        if(char.isnumeric()):
            result.append(chr(ord(char)+2))
        elif(char.isupper()): 
            result.append(chr((ord(char) + syrup-65) % 26 + 65))
        elif(char.islower()):
            result.append(chr((ord(char) + syrup- 97) % 26 + 97))
        else:
            result.append(char)
    return result 
def main():
    flag=0
    sugar=input("Enter ingredient:  ")
    if(len(sugar)<30):
        print("Did you even check out the code ? lol")
        exit()
    CHOCOLATE_SUNDAE=Whipped_cream(CoCoAAA( Chocolate_ice_cream(sugar,syrup)),Vanilla_Essence())
    bowl = open('book', 'r')
    Chocolate_Wafers = bowl.readlines()
    for i in range(0,len(CHOCOLATE_SUNDAE)):
        if(cmp((CHOCOLATE_SUNDAE[i]),(int(Chocolate_Wafers[i], 2)))==0):
            flag+=1
    if(flag==0x1f):
        print("Good Work ! \nTake your flag : ",sugar)
    else:
        print("meh!")



if __name__ == "__main__":  
    main()
