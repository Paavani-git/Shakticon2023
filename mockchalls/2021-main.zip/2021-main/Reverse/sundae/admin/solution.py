st=[]
A=[11011111101,11100001101,111011011111001,111000110001001,111011000101001,11110011101,111011000001001,10000011101,111011111010101,111010010010101,111000111110001,11100001101,111011011000001,1100011101,111010100111001,111010010111001,111000110011001,11001111101,111011011001001,11000011101,111011010111001,111011001101001,111001100111001,11010011101,111011001001001,10110101101,111000001000001,111000001000001,111000100011001,1000111101,111010100111001]
key=[66666,55555,44444,33333]
for i in range (len(key)):
        st.append(int((bin(key[i])[3:]),2)^7)
print("Yes ", st)
l=[]
for i in A:
    l.append(int(str(i),2))
    
key=[562,11675,22788,1133]
 
    
for i in key:
    l[28]=((l[28]-66)^i)
for i in key:
    l[26]=((l[26]-38)^i) 
for i in key:
    l[22]=((l[22]+118)^i)
for i in key:
    l[20]=((l[20]+22)^i) 
for i in key:
    l[16]=((l[16]-75)^i) 
for i in key:
    l[14]=((l[14]-115)^i) 
for i in key:
    l[10]=((l[10]+10)^i)
for i in key:
    l[8]=((l[8]+99)^i)
for i in key:
    l[4]=((l[4]-43)^i)
for i in key:
    l[2]=((l[2]+117)^i)
for i in key:
    l[30]=((l[30]-66)^i) 
for i in key:
    l[27]=((l[27]-38)^i)
for i in key:
    l[24]=((l[24]+118)^i) 
for i in key:
    l[21]=((l[21]+22)^i) 
for i in key:
    l[18]=((l[18]-75)^i) 
for i in key:
    l[15]=((l[15]-115)^i) 
for i in key:
    l[12]=((l[12]+10)^i) 
for i in key:
    l[9]=((l[9]+99)^i) 
for i in key:
    l[6]=((l[6]-43)^i)
for i in key:
    l[3]=((l[3]+117)^i) 
gg=[]
n=[]
for i in range(len(l)):
    for j in range(33,127):
        k=((j & 0xf)>>4)|((j<<4))
        m=k^45

        if(m==l[i]):
            n.append(chr(j))
            break


result = [] 
s=4
for i in range(len(n)): 
    char = n[i] 
    if(char.isnumeric()):
        result.append(chr(ord(char)-2))
    elif(char.isupper()): 
        result.append(chr((ord(char) - s-65) % 26 + 65))
    elif(char.islower()):
        result.append(chr((ord(char) - s-97) % 26 + 97))
    else: 
        result.append(char)
print(''.join(result))
