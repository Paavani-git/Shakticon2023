# sundae


**Challenge File**: [sundae](handout/sundae.cpython-37.pyc)  

**Author**: [bl4ck_Widw](https://twitter.com/N4m1th4_01)

**Description**: Use your python skills to finish making the sundae and get your flag   

**Flag**: inctf{pYTh0n_1s_3aZy_r1gHT!!?!}

**short writeup**: Use the encrypted data in 'book' file to get back the flag after reversing and bruteforceing.
