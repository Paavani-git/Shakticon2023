//gcc -no-pie chall.c -o chall -lm
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>

int red=33,blue=47,black=0,white=1,pink=1;

void calculate(int n)
{
	int i=0;

	while(n>0)
	{
		if (i%2==0)
			white*=(n%10);
		else
			pink*=(n%10);

		red+=(n%10);
		blue|=(n%10);
		black^=(n%10);
		n = (n/10);
		++i;
	}
	white = white/black;
	pink = pink/black;
}


bool check_2(int n) 
{
	int d=log10(n)+1;
	int sum=0;

	while(d>0) 
	{
		sum += (n%10)*(n%10);
		n = n/10;
		d--;
	}

	if (sum==1)
		return true;
	else if (sum / 10 == 0)
		return false;

	return check_2(sum);
}


bool check_1(int num)
{
	int original = num;
	int count = log10(num)+1;
	int sum=0;
	while(num)
	{
		sum+=pow(num%10,count);
		num = num/10;
	}

	if (sum^original)
		return false;
	return check_2(original);
}

void func(char *str1,int *arr)
{
	int len = strlen(str1);
	int brr[len];
	
	for (int i = 0,j=pink; i < len; ++i,j+=3)
	{
		*(arr+i) = *(str1+i) * (j/black) ^ (j+1);
	}
	
	int k=0;

	for (int i = 0; i < len; i+=2)
	{
		brr[k] = arr[i^4];
		k++;
	}

	for (int i = 1; i < len; i+=2)
	{
		brr[k] = arr[i^2];
		k++;
	}

	
	if ((brr[38] + 10*len - (blue & black) ==brr[28])&&(brr[28]% (len*10) + 2*pink - (5*black)/3 == brr[22])&&(brr[38]+ 2*len+ (blue ^ white ) +4 ==brr[37]) &&(brr[38] *2  +3*red +4*blue - blue - 2*pink == brr[36]) &&(brr[16] + 2* len + (red|black) ==brr[37]) &&(brr[26]==brr[37]+4*pink+red-8) &&(brr[9] == brr[16]+blue-1)&&(2*brr[16] - ( red ^ white) -21 ==brr[33]) &&(3*(brr[39]>>2)-(blue^pink)  == 2 + brr[33]) &&(brr[33] + 4* len + 3 * ( blue & pink) ==brr[31]) &&(brr[31] + (blue ^ white) + 15 ==brr[34]) &&((brr[19]*2) + 6 -(3*len) ==brr[31]) &&(brr[34] +  len + ( red & blue) + (red & pink)/2 + (blue & pink)==brr[30]) &&((brr[2] * (black+(2^3)) -(black+(4^7)%len)) ==brr[34]%(red*blue))&&(brr[30] +3  == (blue^pink) + (2*brr[15]))&&(2 * (brr[1] +len*5) + (blue ^ white) -2 == brr[30]) &&(brr[1] + 2*len +1 ==brr[29])&&(brr[35]-brr[1] == pink + (red|white))&&(brr[29] +2  + 10*len - (red & pink) ==brr[5])&&(brr[28]==983)&&(brr[18]-brr[29] == (red&black)<<5) &&(brr[32] - (white^pink) == 2*(red|blue) + brr[5] ) &&(brr[13] -2  + ( red ^ white) *2 + (red | black) ==brr[5])&&(brr[13] +1 + (red  & pink) ==brr[25]) &&(brr[23]-(brr[13]>>2)==pink*(red&black)) &&(brr[25] + 2* len + (blue ^ white) +black-3 ==brr[10]) &&(brr[25]==brr[24]+8*len-black+1)&&(brr[7] + (blue|black)+ (red ^ white)%len -1 ==brr[10])&&(brr[10] + 2*len -1 ==brr[8])&&(brr[4] + 2* len + (blue | black) -3 ==brr[7])&&((brr[0] * 3) - (len*2) -6 ==brr[7])&&(brr[6]==brr[4]+blue-2 )  &&(brr[27] + 2* len + brr[27] % len + (red ^ white) +6 == brr[4])&&(brr[27]+ len +4 ==brr[3])&&(brr[27]==brr[20]+2*len+pink-black+1) &&((brr[3] - len)*3 -(blue ^ white) ==brr[11])&&((brr[3]*4)- (brr[3] % len) -21 ==brr[12])&&(brr[14]==980)&&(brr[11]==pink*32) &&((brr[21] *2) +(red ^ white^2) + (blue & white) ==brr[11])&&(brr[17]==3*brr[21]-3*pink+black-1))
		printf("%s\n","G00d");
	else
		printf("%s\n","Incorrect");
	
	
	exit(0);

}


int main(int argc, char const *argv[])
{
	if (argc>1)
	{
		if (atoi(argv[1])>9 && check_1(atoi(argv[1])))
		{

			printf("Input: ");

			char inp1[50],inp2[50],format[10];
			
			scanf("%s",inp1);

			strncpy(format,&inp1[0],6);
			format[7]='\0';
			int len = strlen(inp1);

			if ( strcmp(format,"inctf{") || inp1[len-1]!=125)
			{
				printf("%s\n","Incorrect Flag format");
				exit(0);
			}

			int out[len];
			strncpy(inp2,&inp1[6],len-7);
			inp2[len-7]='\0';

			if (strlen(inp2)%8!=0)
			{
				printf("%s\n","Incorrect len");
				exit(0);
			}

			calculate(atoi(argv[1]));

			func(&inp2[0],&out[0]);
		}
		else
		{
			printf("%s\n","Incorrect argument");
		}
	}
	else
	{
		printf("%s\n","Usage : ./chall argument");
	}

	return 0;
}