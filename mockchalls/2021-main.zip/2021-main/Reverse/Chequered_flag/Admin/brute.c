#include <stdio.h>
#include <math.h>
#include <stdbool.h>

bool check_2(int n) 
{
    int d=log10(n)+1;  //log10(n)+1 gives number of digits in n
    int sum=0;

    while(d>0) 
    {
        sum += (n%10)*(n%10);
        n = n/10;
        d--;
    }

    if (sum==1)
        return true;
    else if (sum / 10 == 0)
        return false;

    return check_2(sum);
}

bool check_1(int num)
{
    int original = num;
    int count = log10(num)+1;
    int sum=0;
    while(num)
    {
        sum+=pow(num%10,count);
        num = num/10;
    }

    if (sum^original)
        return false;
    return check_2(original);
}

int main(int argc, char const *argv[])
{
    int i=10;
    while(1)
    {
        if (check_1(i))
        {
            printf("%d\n",i);
            break;

        }
        i++;
    }

    return 0;
}