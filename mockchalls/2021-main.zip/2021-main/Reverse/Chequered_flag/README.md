# Chequered_flag

**Description**: Pass all the checks and get the flag
P.S: argument is an integer(4 bytes)

**Challenge File**: [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Reverse/Chequered_flag/Handout/chall)

**short writeup**: 

The binary takes an integer through command line and passes it to the 2 functions check_1 and check_2

check_1 - Take each of the digits in number, raise it to No.Of digits, and then take their sum and compare it with the original number

check_2 - Take each of the digits in number, square it, and then take their sum,repeat this operation, if the above transformation yeilds 1 the fn returns True

brute forcing the functions gives `912985153` as our command line argument
We then have a bunch of equations in func which can be solved using z3

**Detailed Writeup**: [Writeup](https://hackmd.io/@barlaabhi/SJA7tjh5F)

**Flag**: `inctf{1t_15_l1ght5_0ut_4nd_w4y_Z3_g00_366b0c41}`

**Author**: Abhishek Barla