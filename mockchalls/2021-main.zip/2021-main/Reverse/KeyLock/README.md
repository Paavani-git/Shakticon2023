# KeyLock

## Description
go go get the flag

## Short writeup
Implementation of double transposition + hill cipher
The key is transposed twice. The first transposed key is used for hill cipher encryption. 
Find inverse of the key matrix and multiply with ciphertext to get the flag.

## Flag
inctf{playingandmezzingwithmatriceshillcipher}

## Author
imm0rt4l_5t4rk

