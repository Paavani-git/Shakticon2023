package main

import (
	"fmt"
	"os"
	"sort"
	"strings"
	"syscall"
)

func lockwithkey(messagevector []uint8, keymatrix [][]uint8, ciphermatrix []uint8, n int) []uint8 {
	var temp int
	for i := 0; i < n; i++ {
		temp = 0
		for x := 0; x < n; x++ {
			temp += int(keymatrix[i][x]) * int(messagevector[x])
		}
		temp = temp % 26
		ciphermatrix[i] = uint8(temp)
	}
	return ciphermatrix

}

func getKeyring(key string, n int) [][]uint8 {
	k := 0

	keymatrix := make([][]uint8, n)
	for i := range keymatrix {
		keymatrix[i] = make([]uint8, n)
	}
	//print(len(key))
	for i := 0; i < n; i++ {
		for j := 0; j < n; j++ {
			keymatrix[i][j] = uint8(key[k]) % 97
			k = k + 1
		}
	}

	return keymatrix
}

func Sortkey(w string) string {
	s := strings.Split(w, "")
	sort.Strings(s)
	return strings.Join(s, "")
}

func checkkey(cipher string) bool {
	if cipher == "-dkucpejhde-htIexfnlbrslraaa" {
		return true
	} else {
		return false
	}
}

func losingmykey(msg string) string {
	var char_list = []rune(msg)
	key := "HACK"
	key_sort := Sortkey(key)

	col := len(key)
	row := len(msg) / col
	if len(msg)%col > 0 {
		row = row + 1
	}

	fill_null := (row * col) - len(msg)

	for i := 0; i < fill_null; i++ {
		char_list = append(char_list, ' ')
	}

	k := 0
	matrix := make([][]rune, row)
	for i := 0; i < row; i++ {
		for j := 0; j < col; j++ {
			matrix[i] = append(matrix[i], char_list[k])
			k = k + 1
		}
	}

	var transposed []rune
	for i := 0; i < col; i++ {
		curr_idx := strings.Index(key, string(key_sort[i]))
		for j := 0; j < row; j++ {
			transposed = append(transposed, matrix[j][curr_idx])
		}

	}

	return (string(transposed))

}

func main() {

	n := 4
	fmt.Print("Enter key: ")
	var inp string
	fmt.Scanln(&inp)

	_, _, res := syscall.RawSyscall(syscall.SYS_PTRACE, uintptr(syscall.PTRACE_TRACEME), 0, 0)
	if res == 1 {
		fmt.Println("Exiting")
		os.Exit(0)
	}

	cipher := losingmykey(inp)

	cipher2 := losingmykey(cipher)

	if checkkey(cipher2) == false {
		os.Exit(1)
	}

	fmt.Print("Enter flag: ")
	var message string
	fmt.Scanln(&message)

	keymatrix1 := make([][]uint8, 4)
	for i := range keymatrix1 {
		keymatrix1[i] = make([]uint8, 4)
	}

	keymatrix2 := make([][]uint8, 3)
	for i := range keymatrix2 {
		keymatrix2[i] = make([]uint8, 3)
	}

	//messagevector := make([]uint8, n)
	ciphermatrix := make([]uint8, n)

	var ciphertext string
	ciphertext = ""

	arr := [11]int{4, 4, 3, 4, 3, 3, 4, 4, 4, 3, 3}

	keymatrix1 = getKeyring(cipher[2:18], 4)

	keymatrix2 = getKeyring(cipher[19:28], 3)

	place_cnt := 0

	if len(message) != 39 {
		os.Exit(1)
	}

	for k := 0; k < 11; k++ {

		n = arr[k]

		messagevector := make([]uint8, n)

		for i := 0; i < n; i++ {
			messagevector[i] = uint8(message[place_cnt+i] % 97)
		}

		place_cnt += n

		if n == 3 {
			ciphermatrix = lockwithkey(messagevector, keymatrix2, ciphermatrix, n)
		} else if n == 4 {
			ciphermatrix = lockwithkey(messagevector, keymatrix1, ciphermatrix, n)
		}
		for i := 0; i < n; i++ {
			ciphertext = ciphertext + string(rune(ciphermatrix[i]+97))
		}

	}

	if ciphertext == "exwjfmptfzfnpacgjkcldbpdruakyqkurbdenoa" {
		fmt.Printf("Your flag is inctf{%s}\n", message)
	}

}

/*
inputkey = eIspr-xhnjkacrdb-eleadftlhua
key to hill cipher = I-jredhsxkdlfuernc-alphabeta
double key to be checked = -dkucpejhde-htIexfnlbrslraaa

flag input = playingandmezzingwithmatriceshillcipher
flag cipher = exwjfmptfzfnpacgjkcldbpdruakyqkurbdenoa
*/

/*Option: P7ay1ng_4nD_m3s51nG_w1th_m4tric3s lwzdjbkjtqnrysjguzxzjlcdubpdrapll*/
