#include<windows.h>
#include<debugapi.h>
#include<iostream>
#include<string>
#include<stdlib.h>


void call_debug_check() {
	if (IsDebuggerPresent()) {
		puts("YEEEEEEEEEEET!");
		exit(0);
	}
}

std::string return_uppercase() {
	std::string t = "";

	for (int i = 65; i <= 90; i++) {
		t += (char)i;
	}

	return t;
}


std::string return_lowercase() {
	std::string t = "";

	for (int i = 97; i <= 122; i++) {
		t += (char)i;
	}

	return t;
}


std::string mix(char *msg, std::string table, int N, int M, int len) {
	std::string t = "";

	for (int i = 0; i < strlen(msg); i++) {
		if (msg[i] != ' ') {
			for (int j = 0; j < N; j++) {
				if (j == M) {
					t += msg[i];
				}
				else {
					t += table[rand() % len];
				}
			}
			t += ' ';
		}
	}

	return t;
}

std::string encrypt(char *msg, int N, int M) {
	std::string table = "";

	table += return_uppercase();

	table += return_lowercase();

	int len = table.length();

	std::string enc_msg = "";

	enc_msg = mix(msg, table, N, M, len);

	return enc_msg;
}


unsigned int make_seed(int seed1, int seed2) {
	unsigned int res;

	res = ((seed2 & 0xff) << 0x8) | (seed1 & 0xff);

	return res;
}

int main() {

	puts("Glad you are here! This is a useless program printing a useless cipher with some useless tricks");
	puts("To start off, lets get some inputs from you to start encoding your input");
	puts("Enter your input, oh and make sure you know which input is for which ;)");

	int seed_part1, seed_part2, N, M;

	call_debug_check();

	scanf("%d\n", &seed_part1);

	scanf("%d\n", &N);

	call_debug_check();

	char msg[100];

	fgets(msg, 60, stdin);

	msg[strlen(msg) - 1] = '\0';

	std::cin >> M;

	std::cin >> seed_part2;

	call_debug_check();

	unsigned int seed;

	seed = make_seed(seed_part1, seed_part2);

	srand(seed);

	call_debug_check();

	std::string enc_msg = encrypt(msg, N, M);

	std::cout << "Encrypted Message: " << enc_msg << std::endl;

	return 0;
}