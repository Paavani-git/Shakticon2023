# USLS Encrypter

### Challenge Description

The USLS company invented a new encryption system called USLS_v1.0 . They were so confident in it's security that they adapted it everywhere they use. They also had a encrypter for it which could encrypt their communication. They called it the *drum rolls* **USLS Encrypter** *(pun intended)*. Now to test it's efficacy I am giving it to you. In order to make it easy I shall provide you with a few more details, 

```
seed: 4919
Length of each block: 7
USLS key: 3
Encrypted msg: iKl1FKp wYjszny MLcTWhN ZUdhwdG vKw1AEe hCgsmxr VRFAkgm esdwKQq mbh4bat IFrrtqb tAfmbRw UhXUNoB WPMpmQL ndMCTOO qCFhscQ uLz4Whx MpglyfF otvlXcC LGS3JNu nvhnKWU wsEgkyf rCE3wYO
```

Find the flag and good luck !

*p.s. the input might not show any prompt, use your reversing skills to find how to provide the input and what each of them are used for, once you do, the above provided details will help you to not only identify what the inputs are, but also the order to input them ;)*

**Note:** Don't forget to enclose the flag in `inctf{flag_found}`

**Challenge File**:
+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Reverse/USLS_Encrypter/Handout/USLS_Encrypter.exe)

### Short Writeup

This is a implementation of Null Cipher. Just like null cipher, the program generates a lot of useless noise using the seed and other details you provide.

As for the order of the inputs, it should look like this ideally, 
```
55
7
1sTh1sAw4rmUpCh4ll3ng3
3
19
```

where the flag is `1sTh1sAw4rmUpCh4ll3ng3`

Here is the source code for the program, 
```cpp
#include<windows.h>
#include<debugapi.h>
#include<iostream>
#include<string>
#include<stdlib.h>


void call_debug_check() {
    if (IsDebuggerPresent()) {
        puts("YEEEEEEEEEEET!");
        exit(0);
    }
}

std::string return_uppercase() {
    std::string t = "";

    for (int i = 65; i <= 90; i++) {
        t += (char)i;
    }

    return t;
}


std::string return_lowercase() {
    std::string t = "";

    for (int i = 97; i <= 122; i++) {
        t += (char)i;
    }

    return t;
}


std::string mix(char *msg, std::string table, int N, int M, int len) {
    std::string t = "";

    for (int i = 0; i < strlen(msg); i++) {
        if (msg[i] != ' ') {
            for (int j = 0; j < N; j++) {
                if (j == M) {
                    t += msg[i];
                }
                else {
                    t += table[rand() % len];
                }
            }
            t += ' ';
        }
    }

    return t;
}

std::string encrypt(char *msg, int N, int M) {
    std::string table = "";

    table += return_uppercase();

    table += return_lowercase();

    int len = table.length();

    std::string enc_msg = "";

    enc_msg = mix(msg, table, N, M, len);

    return enc_msg;
}


unsigned int make_seed(int seed1, int seed2) {
    unsigned int res;

    res = ((seed2 & 0xff) << 0x8) | (seed1 & 0xff);

    return res;
}

int main() {

    puts("Glad you are here! This is a useless program printing a useless cipher with some useless tricks");
    puts("To start off, lets get some inputs from you to start encoding your input");
    puts("Enter your input, oh and make sure you know which input is for which ;)");

    int seed_part1, seed_part2, N, M;

    call_debug_check();

    scanf("%d\n", &seed_part1);

    scanf("%d\n", &N);

    call_debug_check();

    char msg[100];

    fgets(msg, 60, stdin);

    msg[strlen(msg) - 1] = '\0';

    std::cin >> M;

    std::cin >> seed_part2;

    call_debug_check();

    unsigned int seed;

    seed = make_seed(seed_part1, seed_part2);

    srand(seed);

    call_debug_check();

    std::string enc_msg = encrypt(msg, N, M);

    std::cout << "Encrypted Message: " << enc_msg << std::endl;

    return 0;
}
```  

### Flag

inctf{1sTh1sAw4rmUpCh4ll3ng3}

### Author

**AmunRha**



