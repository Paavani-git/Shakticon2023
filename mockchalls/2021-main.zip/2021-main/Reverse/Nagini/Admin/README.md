```console
sudo apt-get install libsfml-dev
g++ -std=c++11 -c main.cpp -lsfml-graphics -lsfml-window -lsfml-system
g++ main.o -o main -lsfml-graphics -lsfml-window -lsfml-system
./main
```