#include <SFML/Graphics.hpp>
#include <time.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <cstring>

#define SIZE 100

using namespace std;
using namespace sf;

int encrypt(int n)
{
    string s = to_string(n);
    char c[s.length()];
    strcpy(c, s.c_str());
    for (int i = 0; (i < 100 && c[i] != '\0'); i++)
        c[i] = c[i] + 2; //the key for encryption is 3 that is added to ASCII value
    int encrypted_points = atoi(c);
    return encrypted_points;
}

int N = 30, M = 20;
int size = 16;
int w = size * N;
int h = size * M;

int dir, num = 4;

struct Snake
{
    int x, y;
} s[100];

struct Fruct
{
    int x, y;
} f;

void Tick()
{
    int jj = 0;
    for (int i = num; i > 0; --i)
    {
        s[i].x = s[i - 1].x;
        s[i].y = s[i - 1].y;
    }

    if (dir == 0)
        s[0].y += 1;
    if (dir == 1)
        s[0].x -= 1;
    if (dir == 2)
        s[0].x += 1;
    if (dir == 3)
        s[0].y -= 1;

    if ((s[0].x == f.x) && (s[0].y == f.y))
    {
        num++;
        cout << "\033[2J\033[1;1H";
        cout << endl
             << "8    8888 b.             8     ,o888888o. 8888888 8888888888 8 8888888888   " << endl;
        cout << "8    8888 888o.          8    8888     `88.     8 8888       8 8888         " << endl;
        cout << "8    8888 Y88888o.       8 ,8 8888       `8.    8 8888       8 8888         " << endl;
        cout << "8    8888 .`Y888888o.    8 88 8888              8 8888       8 8888         " << endl;
        cout << "8    8888 8o. `Y888888o. 8 88 8888              8 8888       8 888888888888 " << endl;
        cout << "8    8888 8`Y8o. `Y88888o8 88 8888              8 8888       8 8888         " << endl;
        cout << "8    8888 8   `Y8o. `Y8888 88 8888              8 8888       8 8888" << endl;
        cout << "8    8888 8      `Y8o. `Y8 `8 8888       .8'    8 8888       8 8888         " << endl;
        cout << "8    8888 8            `Yo     `8888888P'       8 8888       8 8888         " << endl;
        cout << endl;
        cout << endl;
        cout << "points: " << num - 3 << endl;
        int pointss = encrypt(num - 3);
        if (encrypt(pointss) == 327)
        {
            string command;
            string cmd1 = "strings ";
            string cmd2 = "images";
            string cmd3 = "greenbi0s.jpg";
            string cmd4 = "red.png";
            string cmd = cmd1 + cmd2 + "/" + cmd3;
            command = cmd;
            char *command_char = new char[command.length() + 1];
            strcpy(command_char, command.c_str());
            // store the output of the command in a string
            string output = "";
            char buffer[128];
            FILE *fp;
            fp = popen(command_char, "r");
            if (fp == NULL)
            {
                cout << "Failed to run :/" << endl;
            }
            while (fgets(buffer, sizeof(buffer), fp) != NULL)
            {
                output += buffer;
            }
            pclose(fp);
            cout << (char)(output[32] + 4) << (char)(output[15] - 0) << (char)(output[1] + 29) << (char)(output[4] + 106) << (char)(output[27] + 61) << (char)(output[27] + 82) << (char)(output[4] + 89) << (char)(output[21] - 13) << (char)(output[28] + 78) << (char)(output[33] - 3) << (char)(output[27] + 73) << (char)(output[28] + 20) << (char)(output[23] + 33) << (char)(output[21] + 54) << (char)(output[1] - 37) << (char)(output[32] - 68) << (char)(output[16] + 43) << (char)(output[12] - 20) << (char)(output[4] + 109) << (char)(output[32] - 6) << (char)(output[4] + 111) << (char)(output[1] - 22) << (char)(output[28] + 85) << (char)(output[34] - 51) << (char)(output[4] + 98) << (char)(output[5] + 74) << (char)(output[4] + 85) << (char)(output[4] + 88) << (char)(output[27] + 10) << (char)(output[1] + 25) << (char)(output[2] - 21) << (char)(output[4] + 88) << (char)(output[23] + 25) << (char)(output[1] + 31) << (char)(output[26] + 58) << (char)(output[38] + 36) << (char)(output[27] + 7) << (char)(output[36] - 22) << (char)(output[4] + 89) << (char)(output[23] - 35) << (char)(output[27] + 68) << (char)(output[17] + 64) << (char)(output[21] + 56) << (char)(output[10] + 18) << (char)(output[16] - 18) << (char)(output[29] - 10) << (char)(output[27] + 11) << (char)(output[6] + 67) << (char)(output[13] + 59) << (char)(output[38] + 15) << (char)(output[4] + 109) << (char)(output[4] + 39) << (char)(output[7] + 35) << (char)(output[4] + 94) << (char)(output[4] + 85) << (char)(output[36] - 39) << (char)(output[4] + 42) << (char)(output[32] + 2) << (char)(output[28] + 17) << (char)(output[8] - 4) << (char)(output[28] + 17) << (char)(output[4] + 85) << (char)(output[0] - 22) << (char)(output[36] - 2) << (char)(output[11] + 37) << (char)(output[38] - 28) << (char)(output[4] + 85) << (char)(output[33] - 26) << (char)(output[4] + 42) << (char)(output[37] + 60) << (char)(output[26] + 78) << (char)(output[0] - 23) << (char)(output[6] + 59) << (char)(output[8] - 5) << (char)(output[36] - 69) << (char)(output[15] + 7) << (char)(output[26] + 79) << (char)(output[12] + 36) << (char)(output[36] + 8) << endl;

        } //inctf{c0ngr4ts!!n0w_y0u'll_b3_4ble_t0_c0mmun1c4te_w1th_N4g1n1_4s_4_P4rs3lm0uth}
        jj++;
        f.x = rand() % N;
        f.y = rand() % M;
    }

    if (s[0].x > N)
        s[0].x = 0;
    if (s[0].x < 0)
        s[0].x = N;
    if (s[0].y > M)
        s[0].y = 0;
    if (s[0].y < 0)
        s[0].y = M;

    for (int i = 1; i < num; i++)
        if (s[0].x == s[i].x && s[0].y == s[i].y)
            num = i;
}

int main()
{
    srand(time(0));

    RenderWindow window(VideoMode(w, h), "Rebirth of Nagini!");

    Texture t1, t2;
    t1.loadFromFile("images/red.png");
    t2.loadFromFile("images/greenbi0s.jpg");

    Sprite sprite1(t1);
    Sprite sprite2(t2);

    Clock clock;
    float timer = 0, delay = 0.1;

    f.x = 10;
    f.y = 10;

    while (window.isOpen())
    {
        float time = clock.getElapsedTime().asSeconds();
        clock.restart();
        timer += time;

        Event e;
        while (window.pollEvent(e))
        {
            if (e.type == Event::Closed)
                window.close();
        }

        if (Keyboard::isKeyPressed(Keyboard::Left))
            dir = 1;
        if (Keyboard::isKeyPressed(Keyboard::Right))
            dir = 2;
        if (Keyboard::isKeyPressed(Keyboard::Up))
            dir = 3;
        if (Keyboard::isKeyPressed(Keyboard::Down))
            dir = 0;

        if (timer > delay)
        {
            timer = 0;
            Tick();
        }

        ////// draw  ///////
        window.clear();

        for (int i = 0; i < N; i++)
            for (int j = 0; j < M; j++)
            {
                sprite1.setPosition(i * size, j * size);
                window.draw(sprite1);
            }

        for (int i = 0; i < num; i++)
        {
            sprite2.setPosition(s[i].x * size, s[i].y * size);
            window.draw(sprite2);
        }

        sprite2.setPosition(f.x * size, f.y * size);
        window.draw(sprite2);

        window.display();
    }

    return 0;
}