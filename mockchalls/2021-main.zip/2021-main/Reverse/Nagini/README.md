# Rebirth of Nagini

### Chall Description

- Nagini is too hungry. Feed Nagini till it gives you the flag ;) .
- Flag format : inctf{}

**Challenge File**

+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/blob/main/Reverse/Nagini/Handout/Nagini.zip)

### Short writeup

- Simple GUI based chall using sfml library.
- Player has to get 105 points to get the flag.
- the flag gets decrypted by manupulating the charecters of ``strings images/greenbi0s`` :P .

### Flag

inctf{c0ngr4ts!!n0w_y0u'll_b3_4ble_t0_c0mmun1c4te_w1th_N4g1n1_4s_4_P4rs3lm0uth}

### Author

[Ad0lphus](https://twitter.com/Ad0lphu5)
