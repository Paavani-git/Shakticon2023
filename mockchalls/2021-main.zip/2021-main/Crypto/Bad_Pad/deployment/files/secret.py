AES_KEY = bytes.fromhex("e93e1cf2f5a2bb02b146f90bff031cb0")
FLAG = b"inctf{pAdD1ng_is_n0t_bAd_y0u_a7e_chAMp_in_pAdD1nG}"


