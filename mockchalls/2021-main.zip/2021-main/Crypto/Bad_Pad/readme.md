## Challenge name
Bad_Pad
## Challenge Description
Is Padding Secured?
### Difficulty Level
Hard
### Points
400
### Flag format 
inctf{...}
### challenge file

### Short writeup

### Flag
`inctf{pAdD1ng_is_n0t_bAd_y0u_a7e_cAMp_in_pAdD1nG}`
### Author
chandu kona
