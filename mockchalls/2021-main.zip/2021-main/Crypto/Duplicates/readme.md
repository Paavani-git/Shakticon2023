## Challenge name
Duplicates
### Description
Is it possible to duplicate?
### Difficulty Level
Medium
### Points
200
### Flag format 
inctf{...}
### Short Writeup
* phi is lcm(p-1,q-1),from that we get d2 which gives us flag

### Author

careless_finch

### Flag
`inctf{Seems_l1k3_LCM_1s_n0t_Us3less}`
