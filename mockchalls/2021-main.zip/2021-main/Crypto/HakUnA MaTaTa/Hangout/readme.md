## Challenge name
HakUnA MaTaTa 
## Challenge Description
My friend said that no one can find his message. Is it so?
Help me to retrieve that message.
### Difficulty Level
Medium
### Points
200
### Flag format 
inctf{...}
### challenge file
[Challenge file](parameter.py)
### Author
[Pavani](https://twitter.com/Paavani21)
