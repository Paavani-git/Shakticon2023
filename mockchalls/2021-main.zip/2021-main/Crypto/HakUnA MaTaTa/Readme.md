## Challenge name
HakUnA MaTaTa 
## Challenge Description
My friend said that no one can find his message. Is it so?
Help me to retrieve that message.
### Difficulty Level
Medium
### Points
200
### Flag format 
inctf{...}
### challenge file
[Challenge file](parameter.py)
### Short writeup
1. See the behaviour of fators
2. Find the public ky encryption
3. If `e` value is large, we have possiblity to use wienar's attack
4. find private key using wienar's attack attack
### Flag
inctf{w7ap_tHe_Tr@p_trAp_tHe_WrAp}
### Author
[Pavani](https://twitter.com/Paavani21)
