from Crypto.Util import number
import random

p = number.getPrime(512)
q = number.getPrime(512)

a=0
	
#condition_1:  q < p < 2q
while(a==0):
	p = random.randrange(q,(2*q))
	a = number.isPrime(p)


n = p*q
d=n

#condition2: d < n**(1/4)
while ( (d**4) > n):
	d = d//100


phi = (p-1)*(q-1)
e = number.inverse(d,phi)
flag = b'inctf{w7ap_tHe_Tr@p_trAp_tHe_WrAp}'

m = number.bytes_to_long(flag)

c = pow(m,e,n)
e_factors = [11,21283,381223,1042273,3973757611,557370871938810091338341829797813494727422618069147579982960105548148267493489639949224165197071111170461136397784701770745080079976901064845875848040208215378383980867889638863775783176650506761995256119004767905737751305276427316326673379064969289258229635489079153019359250208481]
print("\nn="+str(n))
print("\nc= "+str(c))
