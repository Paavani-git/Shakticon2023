## Challenge name
cubRSAic
## Challenge Description
Find the roots and get the flag :))
### Difficulty Level
Medium
### Points
200
### Flag format
inctf{...}
### challenge file
[Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Crypto/cubRSAic/Handout)
### Short writeup
```    
    if x1,x2,x3 are roots of a cubic equation , then the equation will be 

            a*x^3 -(x1+x2+x3)*x^2+(x1*x2+x2*x3+x3*x1)*x-(x1*x2*x2)==0
            b==> x1+x2+x3
            c==>(x1*x2+x2*x3+x3*x1)
            d==>(x1*x2*x3)
```
upon solving the cubic equation we can observe that one of it's root is prime and another root is a perfectsquare which gives a prime on square root,as we got 2 primes and from that we can get the other prime 
### Flag
`inctf{cubic_equation_with_a_prime_root_294a4adf0bad96c471783d6f62f1eae9}`

### Author 
Abhishek Bharadwaj
