## Challenge name
OFB-Madness
### Description
Why always block try stream !!
### Difficulty Level
Medium	
### Points
200
### Flag format 
inctf{...}
### Author
careless_finch
### Flag
`inctf{5ymm3tr1c_Ciph3r5_4r3_345y!!!}`
