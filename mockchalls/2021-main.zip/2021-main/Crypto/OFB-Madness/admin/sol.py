from pwn import *

#io = process("./chall.py")
host, port = "localhost",1337
io = remote(host, port)
rl =lambda : io.recvline()
ru =lambda x: io.recvuntil(x)
sl =lambda x: io.sendline(x)

[rl(),rl()]

t=bytes.fromhex(rl().strip().decode())
iv,ct=t[:16],t[16:]
key=b''
for i in range(3):
    ru(b"> ")
    sl(iv.hex().encode()+b'0'*32)
    iv=bytes.fromhex(rl().strip().decode())
    key+=iv

print(xor(ct,key)[:len(ct)].decode())
