## Challenge name
Copper_Copper_COpper!
### Description
You Know RSA?? I only know Copper!
### Difficulty Level
Hard
### Points
400
### Flag format 
inctf{...}
### Short Writeup

* Retrive `n` from `k`
* Use coppersmith short pad attack to get the flag

### Author

careless_finch

### Flag
`inctf{b0b65d84386297336b20d650f2712da12055707a6bc69c02db12072d807854ba13e4c7b7efd0e8b1e6562f66c93428c5}`
