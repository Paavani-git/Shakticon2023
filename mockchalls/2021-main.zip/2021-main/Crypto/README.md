# Crypto

|S. No.| Challenge Name | Status  | Author |
|:---:|:--------------:|:-------:| :-: |
|1.|[common-extender](./common-extender/)|Done| Abhishek Bharadwaj |
|2.|[cubRSAic](./cubRSAic/)|Done| Abhishek Bharadwaj| 
|3.|[HakUnA MaTaTa](./HakUnA MaTaTa/)|Done| Pavani|  
|4.|[Bad_Pad](./Bad_Pad/)|Done| chandu-kona| 
|5.|[Copper_copper_copper!](./Copper_copper_copper!/)|Done|Prajwal|
|6.|[OFB-Madness](./OFB-Madness/)|Done|Prajwal|
|7.|[Duplicates](./Duplicates/)|Done|Prajwal|
