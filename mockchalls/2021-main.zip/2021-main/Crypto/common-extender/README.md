## Challenge name
common-extender
## Challenge Description
Break the box to get the flag
### Difficulty Level
Medium
### Points
200
### Flag format
inctf{...}
### challenge file
[primaryLink](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Crypto/common-extender/Handout) 
### Short writeup
It's a direct attack (Common-modulus) . Find the extended gcd (Euclidean) to get the flag 
```
     gcd(e1,e2) =1
    == >a*e1 + b*e2 =1
    == >c1^a*c2^b = (M^(e1*a))*(M^(e2*b))
                  = M^((e1*a)+(e2*b))             
                  =M^1 ==>M
```    
### Flag: 
`inctf{common_modulus_uses_extended_gcd}`
### Author
Abhishek Bharadwaj
