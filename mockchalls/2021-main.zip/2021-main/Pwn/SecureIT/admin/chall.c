//  gcc chall.c -o vuln -no-pie -fno-stack-protector -lseccomp -static

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <seccomp.h>
#include <sys/prctl.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/random.h>
#include <time.h>
#include <sys/uio.h>
#include <pthread.h>


void init()
{
    
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);
    alarm(60);
}
static void sandbox(void)
{
    prctl(PR_SET_NO_NEW_PRIVS, 1); // No root access possible
    //Allowing a few syscalls
    scmp_filter_ctx ctx;          
    ctx = seccomp_init(SCMP_ACT_KILL);
    if (!ctx) {
		puts("seccomp_init() error");
		exit(EXIT_FAILURE);
	}
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(lseek), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(mmap), 0);
    //seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(mprotect), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(dup), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(close), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(fcntl), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(fstat), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(nanosleep), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(clock_nanosleep	),0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(dup2), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(munmap), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(alarm), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(writev), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(clone), 0);
    seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(set_robust_list), 0);
    seccomp_load(ctx);


}

     
void burritos()
{
    char amt[10];
    printf("Oohh so you need burritos\n");
    printf("Enter the number of burritos you can eat ->");
    scanf("%s",&amt);
    printf("take this you have %s burritos now", amt);
}

void krusty()
{
    char amtt[40];
    printf("Oohh so you need krusties\n");
    printf("Enter the number of krusties you can eat ->\n");
    scanf("%512s",&amtt);
    printf("take this you have\n");
    printf(amtt);
    printf("\nkrusties now\n");
}


void ice_cream() 
{
    char amttt[40];
    printf("Oohh so you need some sizzling ice cream\n");
    printf("Enter the number of ice creams you can eat ->  ");
    scanf("%s",&amttt);
    printf("take this you have %s ice cream now\n",amttt);
}


int main()
{
        init();
        sandbox();
        char choice;
       char string[] =
  "\n        InCTF Nationals       \n"
  "+-----------------------------+\n"
  "| 1. Burritos    -A             |\n"
  "| 2. Krusties    -B             |\n"
  "| 3. Ice Creams  -C             |\n"             
  "+-----------------------------&\n";

        printf("%s",string);
        //char p[] = ("Enter your choice here -> ");
        //printf("%s",p);
        scanf("%c", &choice);
        
        if(choice == 'A')
        burritos();
        if(choice == 'B')
        
        krusty();
        if(choice == 'C')
        ice_cream();
        
        printf("It is all over");
        return(0);



}
   

