# pack_aplha

## Description:
Help me join my Pack Alpha!

## Short Write-up:
	- Integer overflow vulnerabiity.
	- Make use of an alphanumeric sellcode to pop a shell!

## Difficulty:
Beginner

## Flag:
inctf{4_tru3_4lph4_15_4_tru3_k1ng!!}

## Author:
[d1g174l_f0rtr355](https://twitter.com/BhaskaraShravya)
