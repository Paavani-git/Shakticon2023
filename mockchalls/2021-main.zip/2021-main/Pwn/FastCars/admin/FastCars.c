// gcc -o FastCars FastCars.c -z relro -z now

#include <stdio.h>
#include <stdlib.h>

void *cars[10];
int make2size[] = {0x0,0x18,0x68,0x1f8};

void init(){
	setvbuf(stdin,0,2,0);
	setvbuf(stdout,0,2,0);
	alarm(60);
}

void menu(){
	puts("------------>FastCars<------------");
	puts("  1) Buy Car                      ");
	puts("  2) Sell Car                     ");
	puts("  3) View Car                     ");
	puts("  4) Exit                         ");
	puts("----------------------------------");
	printf("> ");
}

unsigned int car_menu(){
	int option;

	puts("Select make of the car");
	puts("1. Tesla");
	puts("2. Koenigsegg");
	puts("3. Bugatti");
	printf("> ");

	scanf("%d",&option);
	getchar();
	if(option < 0 || option > 3) return 0;
	return make2size[option];
}

void buy_car(){
	int idx = 10;

	for(int i=0;i<10;i++){
		if(cars[i] == NULL){
			idx = i;
			break;
		}
	}
	if(idx == 10){
		puts("Maximum entries reached!");
		return;
	}

	unsigned int size = car_menu();
	char buf[512];
	if(size == 0) return;
	
	cars[idx] = malloc(size);
	printf("Model of Car: ");
	fgets(buf,size,stdin);
	memcpy(cars[idx],buf,size);
	printf("Index: %d\n",idx);
	return;
}

int get_idx(){
	int idx;
	printf("Index: ");
	scanf("%d",&idx);
	getchar();

	if (idx > 9 || idx < 0){
		puts("Invalid index!");
		return 10;
	}

	if(cars[idx] == NULL){
		puts("No entry found at index!");
		return 10;
	}
	return idx;
}

void sell_car(){
	int idx = get_idx();
	if (idx == 10) return;
	free(cars[idx]);
	return;
}

void view_car(){
	int idx = get_idx();
	if (idx == 10) return;
	printf("Model:\n %s\n",cars[idx]);
	return;
}

int main(int argc, char *argv[]){
	init();
	while(1){
		int option;
		menu();
		scanf("%d",&option);
		getchar();

		switch(option){
			case 1:
				buy_car();
				break;
			case 2:
				sell_car();
				break;
			case 3:
				view_car();
				break;
			case 4:
				exit(0);
			default:
				puts("Invalid option!");
				break;
		}
	}
	return 0;
}