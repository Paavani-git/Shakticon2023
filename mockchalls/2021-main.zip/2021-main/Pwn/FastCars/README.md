# FastCars

### Challenge Description

Use uaf to perform fastbin attack

**Challenge File**:
+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Pwn/FastCars/handout/FastCars.zip)

**MD5 Hash**: 00ab676d59db08afd4a02ad25524c23c

### Short Writeup

+ Use uaf on freed chunk in unsorted bin to get libc leak
+ Use uaf to double free fastbin chunks
+ Fastbin attack to get fake chunk near \__malloc_hook and overwrite it with one_gadget
+ Allocate chunk to trigger one_gadget and get shell

### Flag

inctf{g0tta_g0_f4st!}

### Author

**k1R4**