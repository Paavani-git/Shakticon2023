# Harry Pwns

### Challenge Description
Voldermort is back to avenge the potter army. 
Pivot it right in his heart, my fellow death eaters.


**Challenge File**:

Stack pivot

### Flag

inctf{1_5o1eM1y_5we4r}

### Author

**aDHIxx**
