//gcc chall.c -o chall -no-pie -fno-stack-protector

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

char buffer[0x100];

int initialize()
{
  alarm(30);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  setvbuf(stdin, NULL, _IONBF, 0);
  return 0;
}

void gadgets(){
    __asm__("pop %rax ; ret");
    __asm__("pop %rdi ; ret");
    __asm__("pop %rsi ; ret");
    __asm__("pop %rdx ; ret");
    __asm__("syscall  ; ret");
}

void horcrux() {
    char buf[0x20];
    printf("\n\nProve that you are a true death eater by killing him.\n\nHere\'s the address to hidden horcux ;): %p\n>", buffer);
    fgets(buffer, 0x100, stdin);
    printf("Now should I have to order you to send me an owl after you kill him?\nDo it, you peasant!!  -__-\n>");
    fgets(buf, 0x30, stdin);    
}

int main() {
    initialize();
    puts("          _            _.,----,");
    puts("__  _.-._ / '-.        -  ,._  \) ");
    puts("|  `-)_   '-.   \      / < _ )/' }");
    puts("/__    '-.   \   '-,___(c-(6)=(6)");
    puts(", `'.    `._ '.  _,'   >\    '  )");
    puts(":;;,,'-._   '---' (  ( '/`. -='/");
    puts(";:;;:;;,  '..__   ,`-.`)'- '--'");
    puts(";';:;;;;;'-._ /'._|  Y/   _/' \ ");
    puts("     ''''._ F    |  _/ _.'._   `\ ");
    puts("           L    \   \/      '._  \ ");
    puts("   .-,-,_ |     `.  `'---,   \_ _|");
    puts("    //    'L    /  \,   ('--',=`)7");
    puts("  | `._       : _,  \   /'`-._L,_'-._");
    puts("  '--' '-.\__/ _L    .`'         './/");
    puts("               [ (  /");
    puts("                 ) `{");
    puts("                 \__) ");
    puts("\nI'm back to kill avenge this boii !!!");
    puts("\nAll my true death eaters gather up!!");
    horcrux();
    return 0;
}