// gcc -o overwrite_simulator overwrite_simulator.c -no-pie
#include <stdio.h>
#include <stdlib.h>

char hello[] = "Hello there!\n";

void init(){
	setvbuf(stdout, 0, 1, 0);
    setvbuf(stdin, 0, 1, 0);
    alarm(60);
}

void menu(){
	puts("-----------------------------------");
	puts("     Overwrite Simulator v13.37    ");
	puts("-----------------------------------");
	puts(" 1) Overwrite                      ");
	puts(" 2) Say hello                      ");
	puts(" 3) Exit                           ");
	puts("-----------------------------------");
	printf(">> ");
}

void overwrite(){
	int addr;
	char data[9];

	printf("Enter address to overwrite: ");
	scanf("%d",&addr);
	getchar();
	printf("Enter data to be written: ");
	fgets(data,9,stdin);
	memcpy(addr,&data,8);
}

void say_hello(){
	printf(&hello);
}

int main(int argc, char *argv[]){
	
	int option;

	init();
	while(1){

		menu();
		scanf("%d",&option);
		getchar();

		if(option == 1){
			overwrite();
		}
		else if(option == 2){
			say_hello();
		}
		else if(option == 3){
			break;
		}
		else{
			puts("Try again!");
		}
	}

	return 0;

}