# overwrite_simulator

### Challenge Description

Leak libc and overwrite GOT with one_gadget

**Challenge File**:
+ [Primary Link](https://gitlab.com/teambi0s/inctf-nationals/quals/2021/-/tree/main/Pwn/overwrite_simulator/handout/overwrite_simulator.zip)

**MD5 Hash**: 95c7f8afd0dd1f70f4f0b722d2ff3855

### Short Writeup

+ Overwrite global variable "hello" to a format string to leak libc
+ Overwrite GOT(getchar) with one_gadget
+ one_gadget is triggered during next iteration of loop

### Flag

inctf{0v3rwriting_th3_G07_is_e4sy!}

### Author

**k1R4**